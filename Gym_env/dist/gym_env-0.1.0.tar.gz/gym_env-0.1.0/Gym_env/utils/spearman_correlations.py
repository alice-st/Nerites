#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Spearman correlation between observations and actions.

Usage:
  python3 spearman_obs_act.py --csv /path/to/obs_act_training_env1.csv \
      --obs_prefix obs_ --act_prefix act_ --outdir ./spearman_out

Outputs (in --outdir):
  - obs_act_spearman_corr_matrix.csv      (obs x act)
  - obs_act_spearman_pvals_matrix.csv     (obs x act)
  - obs_act_spearman_qvals_matrix.csv     (obs x act, Benjamini–Hochberg FDR)
  - obs_act_spearman_top.csv              (flattened, sorted by |r|)
  - obs_act_spearman_heatmap.png          (imshow heatmap with significance marks)

Notes:
  * “Spearman” is rank correlation (monotonic), robust to nonlinearity and scaling.
  * We do pairwise NaN dropping per (obs_i, act_j).
  * FDR controls the expected false discovery rate over all pairs.
"""

import argparse
import os
import re
from typing import List, Tuple

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from scipy.stats import spearmanr


def natural_sort_key(col: str) -> Tuple[int, str]:
    """
    Sort key that tries to grab trailing integer after a prefix like 'obs_12'.
    Falls back to lexicographic.
    """
    m = re.search(r"(\d+)$", col)
    if m:
        return (int(m.group(1)), col)
    return (10**9, col)


def benjamini_hochberg(pvals: np.ndarray) -> np.ndarray:
    """
    Benjamini–Hochberg FDR correction (vectorized over all p-values).
    Returns q-values in the same shape as pvals.

    If pvals has NaNs, qvals will be NaN at those positions.
    """
    flat = pvals.ravel()
    q = np.full_like(flat, np.nan, dtype=float)

    # indices of finite p-values
    idx = np.where(np.isfinite(flat))[0]
    if idx.size == 0:
        return q.reshape(pvals.shape)

    p = flat[idx]
    m = float(p.size)
    order = np.argsort(p)
    ranks = np.arange(1, p.size + 1, dtype=float)

    # raw BH q-values
    q_raw = p[order] * m / ranks

    # enforce monotonicity from right to left
    q_adj = np.minimum.accumulate(q_raw[::-1])[::-1]
    q_adj = np.clip(q_adj, 0.0, 1.0)

    # scatter back
    q_idx = idx[order]
    q[q_idx] = q_adj
    return q.reshape(pvals.shape)


def compute_spearman(df: pd.DataFrame, obs_cols: List[str], act_cols: List[str],
                     min_samples: int = 10):
    """
    Pairwise Spearman (obs_i vs act_j) with pairwise NaN-dropping.
    Returns corr, pvals, nsamples matrices.
    """
    O, A = len(obs_cols), len(act_cols)
    corr = np.full((O, A), np.nan, dtype=float)
    pval = np.full((O, A), np.nan, dtype=float)
    nmat = np.zeros((O, A), dtype=int)

    for i, oc in enumerate(obs_cols):
        x = df[oc].to_numpy()
        for j, ac in enumerate(act_cols):
            y = df[ac].to_numpy()
            m = np.isfinite(x) & np.isfinite(y)
            n = int(m.sum())
            nmat[i, j] = n
            if n >= min_samples:
                r, p = spearmanr(x[m], y[m])
                corr[i, j] = r
                pval[i, j] = p
            # else: leave as NaN
    return corr, pval, nmat


def make_heatmap(corr: np.ndarray, obs_cols: List[str], act_cols: List[str],
                 sig_mask: np.ndarray, out_png: str):
    """
    Matplotlib-only heatmap; red=positive, blue=negative; dots mark significant (q<alpha).
    """
    fig_w = max(8, min(20, 0.35 * len(act_cols) + 3))
    fig_h = max(6, min(24, 0.35 * len(obs_cols) + 3))
    fig, ax = plt.subplots(figsize=(fig_w, fig_h))
    im = ax.imshow(corr, vmin=-1, vmax=1, cmap="coolwarm", aspect="auto", interpolation="nearest")
    cbar = plt.colorbar(im, ax=ax)
    cbar.set_label("Spearman r", rotation=90)

    ax.set_xticks(np.arange(len(act_cols)))
    ax.set_xticklabels(act_cols, rotation=45, ha="right")
    ax.set_yticks(np.arange(len(obs_cols)))
    ax.set_yticklabels(obs_cols)

    # significance overlay
    ys, xs = np.where(sig_mask)
    for y, x in zip(ys, xs):
        ax.text(x, y, "•", ha="center", va="center", fontsize=9, color="k")

    ax.set_title("Obs–Action Spearman Correlation (• = q < 0.05)")
    plt.tight_layout()
    plt.savefig(out_png, dpi=200)
    plt.close(fig)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--csv", required=True, help="Input CSV with obs_*/act_* columns")
    ap.add_argument("--obs_prefix", default="obs_", help="Prefix for observation columns")
    ap.add_argument("--act_prefix", default="act_", help="Prefix for action columns")
    ap.add_argument("--outdir", default=None, help="Output directory (default: alongside CSV)")
    ap.add_argument("--alpha", type=float, default=0.05, help="FDR q-value threshold")
    ap.add_argument("--top_k", type=int, default=30, help="How many strongest pairs to list")
    ap.add_argument("--min_samples", type=int, default=10, help="Min paired samples per correlation")
    args = ap.parse_args()

    os.makedirs(args.outdir or os.path.dirname(os.path.abspath(args.csv)) or ".", exist_ok=True)
    outdir = args.outdir or os.path.dirname(os.path.abspath(args.csv)) or "."

    df = pd.read_csv(args.csv)
    obs_cols = sorted([c for c in df.columns if c.startswith(args.obs_prefix)], key=natural_sort_key)
    act_cols = sorted([c for c in df.columns if c.startswith(args.act_prefix)], key=natural_sort_key)

    if not obs_cols or not act_cols:
        raise SystemExit(
            f"No columns found (obs_prefix='{args.obs_prefix}', act_prefix='{args.act_prefix}'). "
            f"Available columns: {list(df.columns)[:10]} ..."
        )

    corr, pvals, ns = compute_spearman(df, obs_cols, act_cols, min_samples=args.min_samples)
    qvals = benjamini_hochberg(pvals)
    sig_mask = np.isfinite(qvals) & (qvals < args.alpha)

    # Save matrices
    corr_df = pd.DataFrame(corr, index=obs_cols, columns=act_cols)
    pval_df = pd.DataFrame(pvals, index=obs_cols, columns=act_cols)
    qval_df = pd.DataFrame(qvals, index=obs_cols, columns=act_cols)
    ns_df   = pd.DataFrame(ns,    index=obs_cols, columns=act_cols)

    corr_csv = os.path.join(outdir, "obs_act_spearman_corr_matrix.csv")
    pval_csv = os.path.join(outdir, "obs_act_spearman_pvals_matrix.csv")
    qval_csv = os.path.join(outdir, "obs_act_spearman_qvals_matrix.csv")
    ns_csv   = os.path.join(outdir, "obs_act_spearman_nsamples_matrix.csv")
    corr_df.to_csv(corr_csv)
    pval_df.to_csv(pval_csv)
    qval_df.to_csv(qval_csv)
    ns_df.to_csv(ns_csv)

    # Flatten to top-K table
    O, A = corr.shape
    rows = []
    for i in range(O):
        for j in range(A):
            r = corr[i, j]
            p = pvals[i, j]
            q = qvals[i, j]
            n = ns[i, j]
            if np.isfinite(r):
                rows.append({
                    "obs": obs_cols[i], "act": act_cols[j],
                    "r": r, "abs_r": abs(r), "p": p, "q": q, "n": int(n)
                })
    top = pd.DataFrame(rows).sort_values("abs_r", ascending=False).head(args.top_k)
    top_csv = os.path.join(outdir, "obs_act_spearman_top.csv")
    top.to_csv(top_csv, index=False)

    # Heatmap
    heat_png = os.path.join(outdir, "obs_act_spearman_heatmap.png")
    make_heatmap(corr, obs_cols, act_cols, sig_mask, heat_png)

    # Console summary
    finite = np.isfinite(corr)
    if finite.any():
        mean_abs = float(np.nanmean(np.abs(corr[finite])))
        max_abs = float(np.nanmax(np.abs(corr[finite])))
        print(f"[Spearman] pairs={finite.sum()}  mean|r|={mean_abs:.3f}  max|r|={max_abs:.3f}")
        print(f"Saved:\n  {corr_csv}\n  {pval_csv}\n  {qval_csv}\n  {ns_csv}\n  {top_csv}\n  {heat_png}")
    else:
        print("[Spearman] No finite correlations (check min_samples or data columns).")


if __name__ == "__main__":
    main()
