# analysis/pearson_obs_action.py
import argparse
import numpy as np
import pandas as pd
from scipy.stats import pearsonr
import matplotlib.pyplot as plt

def main(csv_path: str, out_prefix: str = "pearson"):
    df = pd.read_csv(csv_path)
    obs_cols = [c for c in df.columns if c.startswith("obs_")]
    act_cols = [c for c in df.columns if c.startswith("act_")]

    if not obs_cols or not act_cols:
        raise ValueError("CSV must contain obs_* and act_* columns")

    obs = df[obs_cols].values  # (T, N)
    act = df[act_cols].values  # (T, M)
    N, M = obs.shape[1], act.shape[1]

    # Pearson r and p-values for each obs_i vs act_j
    R = np.zeros((N, M), dtype=float)
    P = np.ones((N, M), dtype=float)
    for i in range(N):
        xi = obs[:, i]
        for j in range(M):
            yj = act[:, j]
            r, p = pearsonr(xi, yj)
            R[i, j] = r
            P[i, j] = p

    # Save numeric outputs
    pd.DataFrame(R, index=obs_cols, columns=act_cols).to_csv(f"{out_prefix}_R.csv")
    pd.DataFrame(P, index=obs_cols, columns=act_cols).to_csv(f"{out_prefix}_p.csv")

    # Heatmap (no special styles/colors per your environment)
    plt.figure(figsize=(max(6, M*0.6), max(6, N*0.5)))
    plt.imshow(R, aspect="auto", interpolation="nearest")  # default colormap
    plt.xticks(range(M), act_cols, rotation=45, ha="right")
    plt.yticks(range(N), obs_cols)
    plt.title("Pearson r: observations vs actions")
    plt.colorbar(label="r")
    plt.tight_layout()
    plt.savefig(f"{out_prefix}_heatmap.png", dpi=200)
    print(f"Saved: {out_prefix}_R.csv, {out_prefix}_p.csv, {out_prefix}_heatmap.png")

    # Print strongest relationships
    flat = [(obs_cols[i], act_cols[j], R[i, j], P[i, j]) for i in range(N) for j in range(M)]
    flat.sort(key=lambda t: abs(t[2]), reverse=True)
    print("\nTop |r| pairs:")
    for k in range(min(15, len(flat))):
        oi, aj, r, p = flat[k]
        print(f"{k+1:2d}. {oi} ~ {aj}: r={r:+.3f}, p={p:.2e}")

if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--csv", required=True, help="Path to obs_act_rollout.csv")
    ap.add_argument("--out_prefix", default="pearson", help="Output prefix")
    args = ap.parse_args()
    main(args.csv, args.out_prefix)
