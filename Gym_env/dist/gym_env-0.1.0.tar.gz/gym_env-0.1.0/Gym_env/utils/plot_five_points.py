import numpy as np
import math
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D  # noqa: F401 (registers 3D proj)

# Your flat array -> shape (5,4): x, y, z, yaw (radians)
arr = np.array([
    -3.7538626,    2.279777 ,  -18.68006   ,   0.82584864 , -2.397605,
   3.7495759,  -18.663906 ,    0.82533413 , -1.0409609 ,   5.219023,
 -18.647913 ,    0.8253552,    0.31509417,   6.6890163,  -18.631672,
   0.8262183,    1.6687529,    8.161219  , -18.614426  ,   0.82889986,
], dtype=float).reshape(-1, 4)


x, y, z, yaw = arr.T

# 3D plot with yaw direction arrows
fig = plt.figure()
ax = fig.add_subplot(111, projection='3d')
ax.plot(x, y, z, marker='o')  # path through the points

# Arrow directions from yaw (XY plane), short arrows for visibility
dx = np.cos(yaw) * 0.5
dy = np.sin(yaw) * 0.5
dz = np.zeros_like(dx)
ax.quiver(x, y, z, dx, dy, dz, length=1.0, normalize=False)
ax.set_xlabel('X'); ax.set_ylabel('Y'); ax.set_zlabel('Z')
ax.set_title('Five points with yaw (3D)')
plt.show()

# Top-down XY with yaw arrows
plt.figure()
plt.plot(x, y, marker='o')
plt.quiver(x, y, np.cos(yaw), np.sin(yaw), angles='xy', scale_units='xy', scale=2)
plt.gca().set_aspect('equal', adjustable='box')
plt.xlabel('X'); plt.ylabel('Y')
plt.title('Top-down XY with yaw arrows')
plt.show()
