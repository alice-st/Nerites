import torch
import torch.nn as nn
import os
import time
import gymnasium as gym
import numpy as np
from gymnasium.vector import AsyncVectorEnv

# --- Stable-Baselines3 Imports ---
from stable_baselines3 import SAC
from stable_baselines3.common.env_util import make_vec_env
from stable_baselines3.common.vec_env import VecNormalize
from stable_baselines3.common.vec_env import SubprocVecEnv,DummyVecEnv
from stable_baselines3.common.monitor import Monitor
from stable_baselines3.common.callbacks import EvalCallback
from stable_baselines3.common.env_checker import check_env
import envs
from typing import Callable, List, Optional, Any, Sequence, Tuple, Union
import numpy as np
from gymnasium import Env
from gymnasium.vector import AsyncVectorEnv
from stable_baselines3.common.vec_env import VecEnv
import datetime
   
if __name__ == '__main__':
    ENV_ID = "Nerites_mission_planning-v0"
    LOG_DIR = "Training_data/sac_logs20250625-120831"
    BEST_MODEL_SAVE_PATH = os.path.join(LOG_DIR, "0.5_meters")
    MODEL_PATH = os.path.join(BEST_MODEL_SAVE_PATH, "best_model.zip")

    test_env = gym.make(ENV_ID, headless=False, render_mode=None)
    # test_env = make_vec_env(ENV_ID, n_envs=1, env_kwargs={"headless": False,"render_mode": None})
    # test_env = VecNormalize(test_env, norm_obs=True, norm_reward=True) # Normalize it
    if os.path.exists(MODEL_PATH):
        print(f"--- Loading existing model from {MODEL_PATH} ---")
        model = SAC.load(MODEL_PATH, env=test_env)

        # Tell the loaded model where to log for the *next* training session.
        # The .learn() method will use this path to set up the logger.
        model.tensorboard_log = LOG_DIR
    

        print("\n--- Evaluating the final agent ---")
        for episode in range(50):
            print(f"\n--- Episode {episode + 1} ---")
            # Use the single eval_env for testing
            obs,info = test_env.reset()
            
            for t in range(750):
                # Use deterministic=True for the best action during evaluation
                action, _states = model.predict(obs, deterministic=True)
                obs, reward, terminated, truncated,info = test_env.step(action)
                if t == 749:
                    print(obs)
                if terminated or truncated:
                    print(f"Episode finished after {t+1} timesteps.")
                    print(f"Terminated: {terminated}, Truncated: {truncated}")
                    print(f"Final Observation:\n{obs}")
                    print(f"Final Reward: {reward}")
                    break
                    
     
        test_env.close()