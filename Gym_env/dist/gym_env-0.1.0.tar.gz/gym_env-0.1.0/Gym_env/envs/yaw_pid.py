# pid_yaw.py
import math

class YawPID:
    def __init__(self, Kp=200.0, Ki=15.0, Kd=35.0, u_max=400.0, tau_d=0.05):
        """
        Kp, Ki, Kd : PID gains
        u_max      : absolute action limit (use env.action_space.high[0])
        tau_d      : derivative low-pass time constant [s]
        """
        self.Kp, self.Ki, self.Kd = float(Kp), float(Ki), float(Kd)
        self.u_max = float(u_max)
        self.tau_d = float(tau_d)
        self.reset()

    # def reset(self):
    #     self.I = 0.0
    #     self.e_prev = 0.0
    #     self.d_prev = 0.0
    #     self.yaw_ref_prev = None

    # @staticmethod
    # def ang_diff(a, b):
    #     # wrap (a-b) to [-pi, pi]
    #     return ((a - b + math.pi) % (2.0 * math.pi)) - math.pi


