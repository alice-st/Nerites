#!/usr/bin/env python3
from __future__ import annotations

import os
import sys
import ast
import math
import time
import uuid
import signal
import atexit
import threading
from typing import Optional, Tuple, List
import gymnasium as gym
from gymnasium import spaces
import numpy as np
import subprocess
import pandas as pd
import rclpy
from rclpy.time import Time as RclpyTime
from rclpy.parameter import Parameter

from nav_msgs.msg import Odometry
from std_srvs.srv import Empty
from gazebo_msgs.srv import SpawnEntity, DeleteEntity
from uuv_gazebo_ros_plugins_msgs.msg import FloatStamped

from utils import *
from local_planner.waypoint_generator import WaypointHandler

# Optional messages for waypoint listening (if available)
try:
    from uuv_control_msgs.msg import Trajectory
except Exception:
    Trajectory = None
try:
    from nav_msgs.msg import Path
except Exception:
    Path = None
try:
    from geometry_msgs.msg import PoseArray
except Exception:
    PoseArray = None


CONFIG_PATH = "~/ros2_ws/src/Gym_env/settings.txt"

# ----------------------------- Environment ----------------------------- #
class NeritesMissionPlanning(gym.Env):
    metadata = {"render_modes": ["human", "rgb_array"], "render_fps": 30}

    def __init__(
        self, *,
        config_path: Optional[str] = None,
        headless: Optional[bool] = None,
        render_mode: Optional[str] = None,
        uuv_name: Optional[str] = None,
        num_thrusters: Optional[int] = None,
        num_goals: Optional[int] = None,
        goal_distance: Optional[float] = None,
        goal_threshold: Optional[float] = None,
        max_episode_steps: Optional[int] = None,
        thruster_boost: Optional[float] = None,

    ) -> None: 
        super().__init__()

        # --- load settings & apply overrides ---
        cfg = load_settings_txt(CONFIG_PATH)
        if headless is not None:          cfg["headless"] = headless
        if render_mode is not None:       cfg["render_mode"] = render_mode
        if uuv_name is not None:          cfg["uuv_name"] = uuv_name
        if num_thrusters is not None:     cfg["num_thrusters"] = int(num_thrusters)
        if num_goals is not None:         cfg["num_goals"] = int(num_goals)
        if goal_distance is not None:     cfg["goal_distance"] = float(goal_distance)
        if goal_threshold is not None:    cfg["goal_threshold"] = float(goal_threshold)
        if max_episode_steps is not None: cfg["max_episode_steps"] = int(max_episode_steps)
        if thruster_boost is not None:    cfg["thruster_boost"] = float(thruster_boost)

        # --- ROS init ---
        if not rclpy.ok():
            rclpy.init()

        unique_id = uuid.uuid4().hex[:8]
        node_name = f"mission_planner_node_{unique_id}"

        self.node = rclpy.create_node(node_name)
        self.node.set_parameters([Parameter('use_sim_time', rclpy.Parameter.Type.BOOL, True)])
        self.node.get_logger().info("NeritesMissionPlanning environment initializing…")

        atexit.register(self.close)

        # --- config fields ---
        self.headless = str2bool(cfg["headless"])
        self.uuv_name = str(cfg["uuv_name"])
        self.num_thrusters = int(cfg["num_thrusters"])
        self.thruster_boost = float(cfg["thruster_boost"])
        self.max_episode_steps = int(cfg["max_episode_steps"])
        self.distance_goal_threshold = float(cfg["goal_threshold"])
        self.render_mode = cfg["render_mode"]
        assert (self.render_mode is None) or (self.render_mode in self.metadata["render_modes"])
        # paths/topics
        self.WORLD_LAUNCH = cfg["WORLD_LAUNCH"]
        self.MODEL_LAUNCH = cfg["MODEL_LAUNCH"]
        self.TARGET_SDF = cfg["TARGET_SDF"]
        self.POSE_TOPIC = cfg["POSE_TOPIC"]
        self.THRUSTER_TOPIC_FMT = cfg["THRUSTER_TOPIC_FMT"]
        self.WAYPOINTS_FILE_PATH = cfg["WAYPOINTS_FILE_PATH"]

        # --- sim bringup ---
        self._launch_simulation()
        self.node.get_logger().info("Waiting for Gazebo and robot model…")
        time.sleep(5)

        # --- services ---
        self.reset_sim_client = self.node.create_client(Empty, '/gazebo/reset_world')
        self.unpause_sim_client = self.node.create_client(Empty, '/gazebo/unpause_physics')
        self.spawn_entity_client = self.node.create_client(SpawnEntity, '/gazebo/spawn_entity')
        self.delete_entity_client = self.node.create_client(DeleteEntity, '/gazebo/delete_entity')
        
        # Publish path/marker at low rate for RViz (no heavy recompute)
        self._viz_pub_timer = self.node.create_timer(1.0, self._publish_viz)  # 1 Hz is plenty
        self._viz_ready = True  # set True once coeffs are built
        self._wait_for_services()

        # --- initial pose & goals ---
        self.waypoint_handler = WaypointHandler(self.node)
        self.initial_robot_pose = Pose(0.0, 0.0, -20.0, 0.0)
        self.current_position = self.initial_robot_pose
        self.goal_positions = self.generate_goal()

        # --- state ---
        self.vel_x = 0.0
        self.vel_y = 0.0
        self.vel_z = 0.0
        self.step_counter = 0
        self.terminated = False
        self.truncated = False
        self.pose_updated_after_reset = False
        self.reset_start_time = self.node.get_clock().now()
        self.current_goal_idx = 1
        self.reward_log = []
        # --- spaces ---
        self.observation_dim = 13
        self._define_action_and_observation_spaces()
        self.last_action_taken = np.zeros(self.action_space.shape, dtype=np.float32)

        # --- spawn first target ---
        self._respawn_target()

        # --- pubs/subs ---
        self.thruster_pubs = [
            self.node.create_publisher(FloatStamped, self.THRUSTER_TOPIC_FMT.format(i), 10)
            for i in range(self.num_thrusters)
        ]
        self.pose_subscription = self.node.create_subscription(
            Odometry, self.POSE_TOPIC, self.pose_callback, 10
        )

        self.node.get_logger().info(f"Waiting for initial pose from {self.POSE_TOPIC}…")
        self._wait_for_initial_state()

        self.current_state = self._get_current_observation()
        self.node.get_logger().info("Environment initialized successfully.")

    # ------------------------- Launch / Processes ------------------------- #
    def _launch_simulation(self) -> None:
        gui_arg = "false" if self.headless else "true"

        self.node.get_logger().info(f"Launching Gazebo with gui:={gui_arg}")
       
        self.gazebo_process = subprocess.Popen(
            ["ros2", "launch", self.WORLD_LAUNCH, f"gui:={gui_arg}"],
            preexec_fn=os.setsid, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL
        )

        self.node.get_logger().info("Launching robot model…")
        self.robot_model_process = subprocess.Popen(
            ["ros2", "launch", self.MODEL_LAUNCH],
            preexec_fn=os.setsid, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL
        )

        try:
            ns = f"/{self.uuv_name}"
            self.node.get_logger().info("Starting trajectory_marker_publisher…")
            self.marker_process = subprocess.Popen(
                [
                    "ros2", "run", "uuv_control_utils", "trajectory_marker_publisher.py",
                    "--ros-args",
                    "-r", f"waypoints:={ns}/waypoints",
                    "-r", f"trajectory:={ns}/trajectory",
                    "-r", f"__ns:={ns}",
                ],
                preexec_fn=os.setsid, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL
            )
        except Exception as e:
            self.node.get_logger().error(f"Failed to start trajectory_marker_publisher: {e}")
            self.marker_process = None


    def _wait_for_services(self) -> None:
        self.node.get_logger().info("Waiting for Gazebo services…")
        services = {
            "reset": self.reset_sim_client,
            "unpause": self.unpause_sim_client,
            "spawn": self.spawn_entity_client,
            "delete": self.delete_entity_client,
        }

        for name, client in services.items():
            if not client.wait_for_service(timeout_sec=20.0):
                self.node.get_logger().error(f"Service '{name}' not available. Shutting down.")
                self.close()
                sys.exit(f"Required service '{name}' not found.")
        self.node.get_logger().info("Gazebo services are available.")

    # ------------------------------ Goals ------------------------------ #
    def generate_goal(self):
        self.waypoint_handler.build_random(self.initial_robot_pose, n=3)
        self.waypoint_handler.to_waypointset()

        if self.current_position is not None:
            pos0 = np.array([self.current_position.x,
                             self.current_position.y,
                             self.current_position.z], dtype=float)
            yaw0 = float(self.current_position.yaw)
        else:
            pos0 = np.array([self.initial_robot_pose.x,
                             self.initial_robot_pose.y,
                             self.initial_robot_pose.z], dtype=float)
            yaw0 = float(self.initial_robot_pose.yaw)

        # pnts = self.waypoint_handler.interpolate(pos0, yaw0)

        pnts = self.waypoint_handler.tuples
        coeffs = self.waypoint_handler.build_catmull_rom_coeffs(closed=False)
        self.waypoint_handler.publish_spline_as_path(samples_per_seg=30)
        self.waypoint_handler.publish_spline_as_marker(samples_per_seg=30, width=0.05)
        
        # self.waypoint_handler.publish_waypoints()
        goal_positions = []
        for i, (x, y, z, s) in enumerate(pnts):
            # simple: zero yaw
            yaw = 0.0
            # better: yaw from forward difference if next exists
            if i < len(pnts) - 1:
                nx, ny, nz, _ = pnts[i+1]
                yaw = math.atan2(ny - y, nx - x)
            goal_positions.append(Pose(x, y, z, yaw))
        
        return goal_positions

    def _advance_goal(self) -> None:
        self.current_goal_idx += 1

        if self.current_goal_idx < len(self.goal_positions):
            self.goal_position = self.goal_positions[self.current_goal_idx]

            self._respawn_target()
            self.node.get_logger().info(f"Moving to goal {self.current_goal_idx + 1} at {self.goal_position.pose}")
        else:
            self.terminated = True
            self.node.get_logger().info("All goals reached!")

    # ----------------------------- Gym API ----------------------------- #
    def _define_action_and_observation_spaces(self) -> None:
        self.action_space = spaces.Box(low=-1.0, high=1.0, shape=(self.num_thrusters,), dtype=np.float32)
        self.observation_space = spaces.Box(low=-1000.0, high=1000.0, shape=(self.observation_dim,), dtype=np.float32)

    def _wait_for_initial_state(self) -> None:
        start = time.time()
        while self.current_position is None and rclpy.ok():
            rclpy.spin_once(self.node, timeout_sec=0.1)
            if time.time() - start > 20.0:
                break
        if self.current_position is None:
            self.node.get_logger().error("Never received initial pose. Shutting down.")
            self.close()
            sys.exit("Initial state not received.")
        self.node.get_logger().info("Initial pose received.")

    def reset(self, seed: Optional[int] = None, options: Optional[dict] = None):
        super().reset(seed=seed)
        self.node.get_logger().debug("Resetting environment…")

        self.current_goal_idx = 1
        if len(self.goal_positions):
            self.goal_position = self.goal_positions[self.current_goal_idx]
        else:
            self.node.get_logger().warn("Reset without waypoints; keeping placeholder goal at initial pose.")

        self.pose_updated_after_reset = False
        self.reset_start_time = self.node.get_clock().now()

        reset_future = self.reset_sim_client.call_async(Empty.Request())
        rclpy.spin_until_future_complete(self.node, reset_future, timeout_sec=10.0)
        unpause_future = self.unpause_sim_client.call_async(Empty.Request())
        rclpy.spin_until_future_complete(self.node, unpause_future, timeout_sec=5.0)

        if len(self.goal_positions):
            self._respawn_target()

        self.step_counter = 0
        self.terminated = False
        self.truncated = False
        self.last_action_taken.fill(0)

        wait_start = time.time()
        while not self.pose_updated_after_reset:
            rclpy.spin_once(self.node, timeout_sec=0.1)
            if time.time() - wait_start > 15.0:
                self.node.get_logger().error("Timed out waiting for new pose after reset.")
                break

        self.current_state = self._get_current_observation()
        info = {
            "distance_to_goal": float(np.linalg.norm(self.goal_position.pose - self.current_position.pose)) if self.current_position is not None else None,
            "current_steps": self.step_counter,
            "current_goal_idx": self.current_goal_idx,
        }
        self.node.get_logger().debug(f"Reset complete. Initial obs: {self.current_state[0:3]}")
        return self.current_state, info

    def step(self, action: np.ndarray):
        self.publish_action(action)
        self.last_action_taken = action.astype(np.float32)

        rclpy.spin_once(self.node, timeout_sec=0.001)

        self.step_counter += 1
        self.current_state = self._get_current_observation()

        if not np.all(np.isfinite(self.current_state)):
            self.node.get_logger().error("NaN or Inf detected in state! Terminating episode.")
            self.terminated = True
            return self.current_state, -1000.0, self.terminated, self.truncated, {"is_nan": True}

        reward = self.calculate_reward(max_steps=self.max_episode_steps, goal_tolerance=self.distance_goal_threshold)
        distance_to_goal = float(np.linalg.norm(self.goal_position.pose - self.current_position.pose))

        if distance_to_goal < self.distance_goal_threshold:
            self.node.get_logger().info(
                f"Goal {self.current_goal_idx + 1} reached at step {self.step_counter} with reward {reward:.2f}!"
            )
            reward += 2.0
            self._advance_goal()

        if self.step_counter >= self.max_episode_steps:
            self.truncated = True
            reward -= 0.5

        info = {
            "distance_to_goal": distance_to_goal,
            "current_steps": self.step_counter,
            "current_goal_idx": self.current_goal_idx,
        }
        # self.waypoint_handler.publish_waypoints()
    
        return self.current_state, reward, self.terminated, self.truncated, info

    def render(self):
        return None

    # --------------------------- ROS Callbacks --------------------------- #
    def pose_callback(self, msg: Odometry) -> None:
        if RclpyTime.from_msg(msg.header.stamp) > self.reset_start_time:
            self.pose_updated_after_reset = True

        q = msg.pose.pose.orientation
        yaw = quaternion_to_yaw(q.x, q.y, q.z, q.w)

        self.current_position = Pose(msg.pose.pose.position.x, 
                             msg.pose.pose.position.y, 
                             msg.pose.pose.position.z, 
                             yaw)

        self.vel_x = msg.twist.twist.linear.x
        self.vel_y = msg.twist.twist.linear.y
        self.vel_z = msg.twist.twist.linear.z

    # ---------------------------- Observations --------------------------- #
    # def _get_current_observation(self) -> np.ndarray:
    #     if self.current_position is None:
    #         rel_goal = self.goal_position.subtract(self.current_position)

    #         return np.array([
    #             self.initial_robot_pose.x, self.initial_robot_pose.y, self.initial_robot_pose.z,
    #             self.initial_robot_pose.yaw, 0.0, 0.0, 0.0,
    #             rel_goal.x, rel_goal.y, rel_goal.z,
    #             0.0,
    #         ], dtype=np.float32)

    #     relative_goal = self.goal_position.subtract(self.current_position)

    #     return np.array([
    #         self.current_position.x, self.current_position.y, self.current_position.z,
    #         float(self.current_position.yaw), float(self.vel_x), float(self.vel_y), float(self.vel_z),
    #         relative_goal.x, relative_goal.y, relative_goal.z,
    #         float(self.energy_usage),
    #     ], dtype=np.float32)

    def _get_current_observation(self) -> np.ndarray:
        relative_goal = self.goal_position.subtract(self.current_position)
        # --- NEW: spline-relative features ---
        p_xyz = np.array([self.current_position.x, self.current_position.y, self.current_position.z], float)
        try:
            dist, q_on_spline, seg_idx, t = self.waypoint_handler.distance_to_spline_coeffs(p_xyz)
            # tangent r'(t) = 3a t^2 + 2b t + c
            co = self.waypoint_handler._cr_coeffs[seg_idx]
            tx = (3*co["ax"]*t + 2*co["bx"])*t + co["cx"]
            ty = (3*co["ay"]*t + 2*co["by"])*t + co["cy"]
            yaw_ref = math.atan2(ty, tx)
            yaw_err_to_tangent = wrap_to_pi(yaw_ref - float(self.current_position.yaw))
            total_segments = max(1, len(self.waypoint_handler._cr_coeffs or []))
            progress = float((seg_idx + t) / total_segments)
        except Exception:
            dist = float('inf')
            yaw_err_to_tangent = 0.0
            progress = 0.0
        
        self.node.get_logger().info(f"Distance {dist} yaw {yaw_err_to_tangent} current_position {self.current_position.pose}, goal {self.goal_position.pose}")

        return np.array([
            self.current_position.x, self.current_position.y, self.current_position.z,
            float(self.current_position.yaw),
            float(self.vel_x), float(self.vel_y), float(self.vel_z),
            relative_goal.x, relative_goal.y, relative_goal.z,
            float(dist), float(yaw_err_to_tangent), float(progress),
        ], dtype=np.float32)

    # ------------------------------ Actions ------------------------------ #
    def publish_action(self, action: np.ndarray) -> None:
        for i, pub in enumerate(self.thruster_pubs):
            msg = FloatStamped()
            msg.header.stamp = self.node.get_clock().now().to_msg()
            val = float(np.clip(action[i], -1.0, 1.0) * self.thruster_boost)
            msg.data = val
            pub.publish(msg)

    # ------------------------------ Reward ------------------------------ #
    # def calculate_reward(self, max_steps: int = 200, goal_tolerance: float = 0.3) -> float:
    #     dist = float(np.linalg.norm(self.goal_position.pose - self.current_position.pose))
    #     dist_term = 1.0 / (1.0 + dist)

    #     dx = self.goal_position.x - self.current_position.x
    #     dy = self.goal_position.y - self.current_position.y

    #     angle_to_goal = math.atan2(dy, dx)
    #     yaw_err = wrap_to_pi(angle_to_goal - float(self.current_position.yaw))
    #     orient_term = (math.cos(yaw_err) + 1.0) * 0.5

    #     t = min(self.step_counter, max_steps)
    #     time_term = - float(t) / float(max_steps)

    #     w_dist, w_orient, w_time = 1.0, 0.3, 0.2
    #     reward = w_dist * dist_term + w_orient * orient_term + w_time * time_term

    #     if dist < 0.2:
    #         reward += 0.2 * dist_term * orient_term
    #     if dist <= goal_tolerance:
    #         reward += 2.0

    #     return float(reward)

    def calculate_reward(self, max_steps: int = 200, goal_tolerance: float = 0.3) -> float:
        # --- Closest point on spline ---
        try:
            p_xyz = np.array([self.current_position.x, self.current_position.y, self.current_position.z], dtype=np.float32)
            dist, q_on_spline, seg_idx, t = self.waypoint_handler.distance_to_spline_coeffs(p_xyz)
        except Exception:
            # Fallback if coeffs not ready yet
            dist = float(np.linalg.norm(self.goal_position.pose - self.current_position.pose))
            seg_idx, t = 0, 0.0

        # --- Distance penalty (always <= 0) ---
        d_cap = 10.0  # meters (tune)
        r_dist = - min(float(dist), d_cap) / d_cap  # 0 when on-path, -1 when >= d_cap

        # --- Orientation alignment to spline tangent ---
        try:
            co = self.waypoint_handler._cr_coeffs[seg_idx]
            tx = (3*co["ax"]*t + 2*co["bx"])*t + co["cx"]
            ty = (3*co["ay"]*t + 2*co["by"])*t + co["cy"]
            yaw_ref = math.atan2(ty, tx)
        except Exception:
            dx = self.goal_position.x - self.current_position.x
            dy = self.goal_position.y - self.current_position.y
            yaw_ref = math.atan2(dy, dx)

        yaw_err = wrap_to_pi(yaw_ref - float(self.current_position.yaw))
        r_orient = (math.cos(yaw_err) + 1.0) * 0.5  # in [0,1]

        # --- Time penalty ---
        t_steps = min(self.step_counter, max_steps)
        r_time = - float(t_steps) / float(max_steps)  # in [-1,0]

        # # --- Differential progress along the spline (forward-only) ---
        # total_segments = max(1, len(self.waypoint_handler._cr_coeffs or []))
        # progress = (seg_idx + t) / total_segments
        # progress_delta = max(0.0, progress - self._last_progress)
        # self._last_progress = progress

        # --- Weights (tune) ---
        w_dist, w_orient, w_time, w_prog = 0.6, 0.3, 0.2, 0.2

        reward = (
            w_dist * r_dist +
            w_orient * r_orient)

        # # --- Optional small bonuses near path / at the end ---
        # if dist < 0.2:
        #     reward += 0.1 * r_orient  # small extra only when really close
        # if progress >= 0.99 and dist <= goal_tolerance:
        #     reward += 2.0  # finishing bonus

        # --- (Optional) periodic logging ---
        try:
            import pandas as pd  # safe local import
            if self.step_counter % 1000 == 0 and self.step_counter > 0:
                self.reward_log.append({
                    "step": int(self.step_counter),
                    "reward": float(reward),
                    "dist_m": float(dist),
                    "r_dist": float(r_dist),
                    "r_orient": float(r_orient),
                })
                df = pd.DataFrame(self.reward_log)
                df.to_csv("rewards.csv", index=False)

        except Exception:
            pass

        return float(reward)

    # ------------------------------ Target ------------------------------ #
    def _respawn_target(self) -> None:
        # Delete old target (ignore errors)
        try:
            delete_req = DeleteEntity.Request(name='target_model')
            future_del = self.delete_entity_client.call_async(delete_req)
            rclpy.spin_until_future_complete(self.node, future_del, timeout_sec=5.0)
        except Exception:
            pass

        # Read SDF
        try:
            with open(self.TARGET_SDF, 'r') as f:
                sdf_xml = f.read()
        except FileNotFoundError:
            self.node.get_logger().error(f"Target SDF not found at {self.TARGET_SDF}. Cannot spawn target.")
            return

        spawn_req = SpawnEntity.Request()
        spawn_req.name = 'target_model'
        spawn_req.xml = sdf_xml
        self.goal_position = self.goal_positions[self.current_goal_idx]

        spawn_req.initial_pose.position.x = float(self.goal_position.x)
        spawn_req.initial_pose.position.y = float(self.goal_position.y)
        spawn_req.initial_pose.position.z = float(self.goal_position.z)

        future_spawn = self.spawn_entity_client.call_async(spawn_req)

        rclpy.spin_until_future_complete(self.node, future_spawn, timeout_sec=10.0)
        if future_spawn.result() and not future_spawn.result().success:
            self.node.get_logger().error(f"Failed to spawn target: {future_spawn.result().status_message}")

    def _publish_viz(self):
        # Only publish if we have spline coeffs ready
        if not getattr(self, "_viz_ready", False):
            return
        try:
            # These calls only publish; they reuse cached samples/coeffs in WaypointHandler
            self.waypoint_handler.publish_spline_as_path(samples_per_seg=30, show_orientation=True)
            self.waypoint_handler.publish_spline_as_marker(samples_per_seg=30, width=0.05)
        except Exception as e:
            self.node.get_logger().warn(f"Viz publish failed: {e}")


    # ------------------------------ Shutdown ------------------------------ #
    def close(self) -> None:
        try:
            self.node.get_logger().info("Closing environment and shutting down processes…")
        except Exception:
            pass

        for attr in ("marker_process", "waypoints_process"):
            proc = getattr(self, attr, None)
            if proc is not None and proc.poll() is None:
                try:
                    os.killpg(os.getpgid(proc.pid), signal.SIGTERM)
                    proc.wait(timeout=5)
                except Exception:
                    try:
                        os.killpg(os.getpgid(proc.pid), signal.SIGKILL)
                    except Exception:
                        pass
                finally:
                    setattr(self, attr, None)

        for attr in ("robot_model_process", "gazebo_process"):
            proc = getattr(self, attr, None)
            if proc is not None and proc.poll() is None:
                try:
                    os.killpg(os.getpgid(proc.pid), signal.SIGTERM)
                    proc.wait(timeout=5)
                except Exception:
                    try:
                        os.killpg(os.getpgid(proc.pid), signal.SIGKILL)
                    except Exception:
                        pass
                finally:
                    setattr(self, attr, None)

        if rclpy.ok():
            try:
                self.node.destroy_node()
            finally:
                rclpy.shutdown()

        try:
            self.node.get_logger().info("Environment closed.")
        except Exception:
            pass

# --------- Gym registration factory (used by entry_points) ----------
def make_env(**kwargs) -> NeritesMissionPlanning:
    return NeritesMissionPlanning(**kwargs)
