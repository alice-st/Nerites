import sys
import gymnasium as gym
from gymnasium import spaces
from gymnasium.utils import seeding
import numpy as np
import rclpy
from rclpy.node import Node
from rclpy.time import Time as RclpyTime
from rclpy.parameter import Parameter
from std_msgs.msg import Float32
from nav_msgs.msg import Odometry
from gazebo_msgs.srv import SpawnEntity, DeleteEntity
from std_srvs.srv import Empty
from uuv_gazebo_ros_plugins_msgs.msg import FloatStamped
import subprocess
import time
import uuid
import os
import signal
import math
import atexit

# Helper function for quaternion to yaw
def quaternion_to_yaw(x, y, z, w):
    """Convert quaternion to yaw (rotation around z-axis)."""
    t3 = +2.0 * (w * z + x * y)
    t4 = +1.0 - 2.0 * (y * y + z * z)
    return math.atan2(t3, t4)

class Nerites_mission_planning(gym.Env):
    metadata = {"render_modes": ["human", "rgb_array"], "render_fps": 30}
    
    def __init__(self, headless=True, render_mode=None):
        super(Nerites_mission_planning, self).__init__()

        if not rclpy.ok():
            rclpy.init()
        
        # Create the node
        unique_id = uuid.uuid4().hex[:8]
        node_name = f"mission_planner_node_{unique_id}"
        self.node = rclpy.create_node(node_name)
        param = Parameter('use_sim_time', rclpy.Parameter.Type.BOOL, True)
        self.node.set_parameters([param])

        atexit.register(self.close)
        self.node.get_logger().set_level(rclpy.logging.LoggingSeverity.INFO)
        self.node.get_logger().info("Nerites_mission_planning environment initializing...")
        
        self.headless = headless
        assert render_mode is None or render_mode in self.metadata["render_modes"]
        self.render_mode = render_mode
        self._launch_simulation()
        self.node.get_logger().info("Waiting for Gazebo and robot model to be ready...")
        time.sleep(15)

        # ROS 2 Services
        self.reset_sim_client = self.node.create_client(Empty, '/gazebo/reset_world')
        self.unpause_sim_client = self.node.create_client(Empty, '/gazebo/unpause_physics')
        self.spawn_entity_client = self.node.create_client(SpawnEntity, '/gazebo/spawn_entity')
        self.delete_entity_client = self.node.create_client(DeleteEntity, '/gazebo/delete_entity')
        self._wait_for_services()

        # Environment Parameters
        self.max_episode_steps = 250
        self.goal_positions = [
            np.array([0.4, 0.0, -20.0]),  # First goal
            np.array([0.8, 0.1, -20.0]),  # Second goal
            np.array([1.0, 0.3, -20.0])   # Third goal
        ]
        self.current_goal_idx = 0
        self.goal_position = self.goal_positions[self.current_goal_idx]
        self.initial_robot_pose = {"x": 0.0, "y": 0.0, "z": -20.0, "yaw": 0.0}
        self.distance_goal_threshold = 0.1
        self.thruster_boost = 400.0

        # State Variables
        self.position = None
        self.yaw = None
        self.vel_x, self.vel_y, self.vel_z = 0.0, 0.0, 0.0
        self.energy_usage = 0.0
        self.step_counter = 0
        self.terminated = False
        self.truncated = False
        
        self.pose_updated_after_reset = False
        self.reset_start_time = self.node.get_clock().now()

        self.observation_dim = 11
        self._define_action_and_observation_spaces()
        self.last_action_taken = np.zeros(self.action_space.shape, dtype=np.float32)

        self._respawn_target()

        self.thruster_pubs = [self.node.create_publisher(FloatStamped, f'/x300/thrusters/id_{i}/input', 10) for i in range(10)]
        self.pose_subscription = self.node.create_subscription(Odometry, "/x300/pose_gt", self.pose_callback, 10)

        self.node.get_logger().info("Waiting for initial pose from /x300/pose_gt...")
        self._wait_for_initial_state()
        
        self.current_state = self._get_current_observation()
        self.np_random, _ = seeding.np_random(None)
        self.node.get_logger().info("Environment initialized successfully.")

    def _launch_simulation(self):
        gui_arg = "false" if self.headless else "true"
        gui_arg = "true"
        
        world_launch_file = "/home/alice/ros2_ws/install/uuv_gazebo_worlds/share/uuv_gazebo_worlds/launch/lake.launch.py"
        self.node.get_logger().info(f"Launching Gazebo with gui:={gui_arg}")
        self.gazebo_process = subprocess.Popen(
            ["ros2", "launch", world_launch_file, f"gui:={gui_arg}"],
            preexec_fn=os.setsid, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL
        )

        model_launch_file = "/home/alice/ros2_ws/install/x300_description/share/x300_description/launch/upload_x300_default.launch.py"
        self.node.get_logger().info("Launching robot model.")
        self.robot_model_process = subprocess.Popen(
            ["ros2", "launch", model_launch_file],
            preexec_fn=os.setsid, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL
        )

    def _wait_for_services(self):
        self.node.get_logger().info("Waiting for Gazebo services...")
        services = {
            "reset": self.reset_sim_client,
            "unpause": self.unpause_sim_client,
            "spawn": self.spawn_entity_client,
            "delete": self.delete_entity_client
        }
        for name, client in services.items():
            if not client.wait_for_service(timeout_sec=20.0):
                self.node.get_logger().error(f"Service '{name}' not available. Shutting down.")
                self.close()
                sys.exit(f"Required service '{name}' not found.")
        self.node.get_logger().info("Gazebo services are available.")

    def reset(self, seed=None, options=None):
        super().reset(seed=seed)
        self.node.get_logger().debug("Resetting environment...")

        # Reset goal index and position
        self.current_goal_idx = 0
        self.goal_position = self.goal_positions[self.current_goal_idx]

        # Prepare for reset synchronization
        self.pose_updated_after_reset = False
        self.reset_start_time = self.node.get_clock().now()

        # Reset Gazebo simulation world
        reset_future = self.reset_sim_client.call_async(Empty.Request())
        rclpy.spin_until_future_complete(self.node, reset_future, timeout_sec=10.0)

        # Unpause the simulation
        unpause_future = self.unpause_sim_client.call_async(Empty.Request())
        rclpy.spin_until_future_complete(self.node, unpause_future, timeout_sec=5.0)

        # Reset the target model
        self._respawn_target()

        # Reset internal state variables
        self.step_counter = 0
        self.energy_usage = 0.0
        self.terminated = False
        self.truncated = False
        self.last_action_taken.fill(0)

        # Wait for a new pose message
        wait_start_time = time.time()
        while not self.pose_updated_after_reset:
            rclpy.spin_once(self.node, timeout_sec=0.1)
            if time.time() - wait_start_time > 15.0:
                self.node.get_logger().error("Timed out waiting for new pose after reset.")
                break

        # Get the new observation
        self.current_state = self._get_current_observation()
        info = {
            "energy_usage": self.energy_usage,
            "distance_to_goal": np.linalg.norm(self.goal_position - self.position),
            "current_steps": self.step_counter,
            "current_goal_idx": self.current_goal_idx
        }
        self.node.get_logger().debug(f"Reset complete. Initial obs: {self.current_state[0:3]}")
        return self.current_state, info

    def _respawn_target(self):
        """Deletes any existing target and spawns a new one at the current goal position."""
        delete_req = DeleteEntity.Request(name='target_model')
        future = self.delete_entity_client.call_async(delete_req)
        rclpy.spin_until_future_complete(self.node, future, timeout_sec=5.0)
        
        target_sdf_path = '/home/alice/ros2_ws/src/x300_description/models/target/model.sdf'
        try:
            with open(target_sdf_path, 'r') as f:
                sdf_xml = f.read()
        except FileNotFoundError:
            self.node.get_logger().error(f"Target SDF not found at {target_sdf_path}. Cannot spawn target.")
            return

        spawn_req = SpawnEntity.Request()
        spawn_req.name = 'target_model'
        spawn_req.xml = sdf_xml
        spawn_req.initial_pose.position.x = float(self.goal_position[0])
        spawn_req.initial_pose.position.y = float(self.goal_position[1])
        spawn_req.initial_pose.position.z = float(self.goal_position[2])
        
        future = self.spawn_entity_client.call_async(spawn_req)
        rclpy.spin_until_future_complete(self.node, future, timeout_sec=10.0)
        if future.result() and not future.result().success:
            self.node.get_logger().error(f"Failed to spawn target: {future.result().status_message}")

    def _define_action_and_observation_spaces(self):
        self.action_space = spaces.Box(low=-1.0, high=1.0, shape=(10,), dtype=np.float32)
        self.observation_space = spaces.Box(low=-1000, high=1000, shape=(self.observation_dim,), dtype=np.float32)

    def _wait_for_initial_state(self):
        """Spins until the first pose message is received."""
        while self.position is None and rclpy.ok():
            rclpy.spin_once(self.node, timeout_sec=0.1)
        if self.position is None:
            self.node.get_logger().error("Never received initial pose. Shutting down.")
            self.close()
            sys.exit("Initial state not received.")
        self.node.get_logger().info("Initial pose received.")

    def pose_callback(self, msg: Odometry):
        if RclpyTime.from_msg(msg.header.stamp) > self.reset_start_time:
            self.pose_updated_after_reset = True
        
        self.position = np.array([msg.pose.pose.position.x, msg.pose.pose.position.y, msg.pose.pose.position.z])
        q = msg.pose.pose.orientation
        self.yaw = quaternion_to_yaw(q.x, q.y, q.z, q.w)
        
        self.vel_x = msg.twist.twist.linear.x
        self.vel_y = msg.twist.twist.linear.y
        self.vel_z = msg.twist.twist.linear.z

    def _get_current_observation(self):
        """Constructs the observation from the current internal state."""
        if self.position is None or self.yaw is None:
            rel_goal = self.goal_position - np.array([self.initial_robot_pose["x"], self.initial_robot_pose["y"], self.initial_robot_pose["z"]])
            return np.array([self.initial_robot_pose["x"], self.initial_robot_pose["y"], self.initial_robot_pose["z"], self.initial_robot_pose["yaw"], 0.0, 0.0, 0.0, rel_goal[0], rel_goal[1], rel_goal[2], 0.0], dtype=np.float32)

        relative_goal = self.goal_position - self.position
        return np.array([
            self.position[0], self.position[1], self.position[2],
            self.yaw, self.vel_x, self.vel_y, self.vel_z,
            relative_goal[0], relative_goal[1], relative_goal[2],
            self.energy_usage
        ], dtype=np.float32)

    def step(self, action):
        self.publish_action(action)
        self.last_action_taken = action

        rclpy.spin_once(self.node, timeout_sec=0.001)
        
        self.step_counter += 1
        self.current_state = self._get_current_observation()
        energy_step = np.sum(np.abs(action)) * 0.01
        self.energy_usage += energy_step
        self.current_state[-1] = self.energy_usage
        
        if np.any(np.isnan(self.current_state)) or np.any(np.isinf(self.current_state)):
            self.node.get_logger().error("NaN or Inf detected in state! Terminating episode.")
            self.terminated = True
            return self.current_state, -1000.0, self.terminated, self.truncated, {"is_nan": True}

        reward = self.calculate_reward()
        distance_to_goal = np.linalg.norm(self.goal_position - self.position)
        
        if distance_to_goal < self.distance_goal_threshold:
            self.node.get_logger().info(f"Goal {self.current_goal_idx + 1} reached at step {self.step_counter} with a reward of {reward:.2f}!")
            reward += 1000.0
            self.current_goal_idx += 1
            if self.current_goal_idx < len(self.goal_positions):
                self.goal_position = self.goal_positions[self.current_goal_idx]
                self._respawn_target()
                self.node.get_logger().info(f"Moving to goal {self.current_goal_idx + 1} at {self.goal_position}")
            else:
                self.terminated = True
                self.node.get_logger().info("All goals reached!")
        
        if self.step_counter >= self.max_episode_steps:
            self.truncated = True
            reward -= 100.0
        
        info = {
            "energy_usage": self.energy_usage,
            "distance_to_goal": distance_to_goal,
            "current_steps": self.step_counter,
            "current_goal_idx": self.current_goal_idx
        }
        
        return self.current_state, reward, self.terminated, self.truncated, info

    def publish_action(self, action):
        for i, pub in enumerate(self.thruster_pubs):
            msg = FloatStamped()
            msg.header.stamp = self.node.get_clock().now().to_msg()
            msg.data = float(action[i] * self.thruster_boost)
            pub.publish(msg)

    def calculate_reward(self):
        dist_to_goal = np.linalg.norm(self.goal_position - self.position)
        distance_reward = 1/(dist_to_goal**2)
        
        dx = self.goal_position[0] - self.position[0]
        dy = self.goal_position[1] - self.position[1]
        angle_to_goal = math.atan2(dy, dx)
        
        yaw_error = (angle_to_goal - self.yaw + math.pi) % (2 * math.pi) - math.pi
        
        orientation_reward = math.cos(yaw_error) * 0.5
        time_penalty = -0.05 * self.step_counter

        return distance_reward * 10 + orientation_reward / 5 + time_penalty

    def close(self):
        self.node.get_logger().info("Closing environment and shutting down processes...")
        
        if hasattr(self, 'robot_model_process') and self.robot_model_process.poll() is None:
            os.killpg(os.getpgid(self.robot_model_process.pid), signal.SIGTERM)
            self.robot_model_process.wait(timeout=5)
            self.node.get_logger().info("Robot model process group terminated.")

        if hasattr(self, 'gazebo_process') and self.gazebo_process.poll() is None:
            os.killpg(os.getpgid(self.gazebo_process.pid), signal.SIGTERM)
            self.gazebo_process.wait(timeout=5)
            self.node.get_logger().info("Gazebo process group terminated.")
        
        if rclpy.ok():
            self.node.destroy_node()
            rclpy.shutdown()
        
        self.node.get_logger().info("Environment closed.")

    def render(self):
        return None