#!/usr/bin/env python3
from __future__ import annotations
import math
from typing import Optional, List, Tuple
import numpy as np
from gymnasium import spaces

from envs.base_env import BaseUUVEnv, CONFIG_PATH
from utils import Pose, wrap_to_pi
from local_planner.waypoint_generator import WaypointHandler
import pandas as pd
import json
from collections import deque
from uuv_gazebo_ros_plugins_msgs.msg import FloatStamped

def world_to_body_xy(dx: float, dy: float, dz:float, yaw: float):
    # ---------- helper: world -> body (x fwd, y left) ----------
    # rotate world vector into body (x fwd, y left)
    c, s = math.cos(yaw), math.sin(yaw)
    xb =  c * dx + s * dy
    yb = -s * dx + c * dy
    zb = dz 
    return xb, yb, zb

def wrap_to_2pi(rad):
    twopi = 2.0 * math.pi
    return (rad % twopi + twopi) % twopi

def ang_diff(a, b):
    return ((a - b + math.pi) % (2*math.pi)) - math.pi

class NeritesMissionPlanning(BaseUUVEnv):
    """Custom logic: waypoints/spline, observation vector, reward shaping, spaces."""
    def __init__(self, **kwargs):
        self.env_id = kwargs["env_id"]
        self.waypoint_handler: WaypointHandler | None = None
        self.observation_dim = 10
        self.obs_log = []
        self.analytic_rewards = []
        self.angle_error_buffer = [1] * 50
        self.curriculum_stage = 1    # 1, 2, or 3
        self.epsilon = 0.0           # will grow 0→0.2→1.0
        self.lambda_surge = 1.0      # surge penalty weight, will anneal down
        self.absolute_error_sum = 0.0
        self._avg_abs_e_hist = deque(maxlen=50)   # moving window over episodes
        self._prev_e = 0.0
        self.bonus_reward = 0
        super().__init__(**kwargs)

    # -------- hooks required by BaseUUVEnv --------
    def build_goals(self) -> List[Pose]:
        # Build once; keep handler around for obs/reward
        self.waypoint_handler = WaypointHandler(self.node, self.env_id)
        start = Pose(0.0, 0.0, -20.0, 0.0, 0.0, 0.0)
        self.waypoint_handler.build_random(start, n=self.number_of_target_waypoints)
        pnts = self.waypoint_handler.goal_waypoints  # [(x,y,z,s), ...]
        self.waypoint_handler.build_catmull_rom_coeffs(closed=False)

        goals: List[Pose] = []
        for i, (x, y, z, _) in enumerate(pnts):
            yaw = 0.0
            if i < len(pnts) - 1:
                nx, ny, nz, _ = pnts[i+1]
                yaw = math.atan2(ny - y, nx - x)
            goals.append(Pose(x, y, z, 0.0, 0.0, yaw))
        
        return goals

    def define_spaces(self) -> Tuple[spaces.Space, spaces.Space]:
        action_space = spaces.Box(low=-1.0, high=1.0, shape=(1,), dtype=np.float32)
        observation_space = spaces.Box(low=-1e3, high=1e3, shape=(self.observation_dim,), dtype=np.float32)
        return action_space, observation_space
        
    def update_current_state(self) -> None:
        """
        Refresh vehicle state, spline tangent & references, heading error metrics,
        and goal offsets in both world and body frames.
        """
        EPS = 1e-9  # for safe divisions

        # --- Orientation (wrap where appropriate)
        self.current_yaw   = wrap_to_2pi(self.current_position.yaw)           
        self.roll_rate, self.pitch_rate, self.yaw_rate = self.current_speed.angular_velocity
        self.vx, self.vy, self.vz = self.current_speed.linear_velocity

        # --- Position vectors
        self.current_goal = self.goal_positions[self.current_goal_idx]
        self.current_position_vec = self.current_position.pose

        # --- Closest point on spline & segment parameters
        self.dist_s, self.q_on_spline, self.seg_idx, self.t = (
            self.waypoint_handler.distance_to_spline_coeffs(self.current_position_vec))

        co = self.waypoint_handler._cr_coeffs[self.seg_idx]  # {ax, bx, cx, ay, by, cy, az, bz, cz}

        # --- Tangent vector at (seg_idx, t) using Horner form
        t = float(self.t)
        self.tx = ((3.0 * co["ax"] * t + 2.0 * co["bx"]) * t) + co["cx"]
        self.ty = ((3.0 * co["ay"] * t + 2.0 * co["by"]) * t) + co["cy"]
        self.tz = ((3.0 * co["az"] * t + 2.0 * co["bz"]) * t) + co["cz"]

        # --- Reference yaw / pitch from tangent
        self.yaw_ref = wrap_to_2pi(math.atan2(self.ty, self.tx))
        horiz = math.hypot(self.tx, self.ty)
        self.pitch_ref = math.atan2(self.tz, max(horiz, EPS))  # (-pi/2, pi/2)
        
        # --- Heading error (wrapped) and alignment scalar in [0, 1]
        self.yaw_err_to_tangent = ang_diff(self.yaw_ref, self.current_yaw)
        self.heading_align = 0.5 * (1.0 + math.cos(self.yaw_err_to_tangent))  # [0, 1]
        self.angle_error_buffer.append(self.heading_align)
        self.angle_error_buffer = self.angle_error_buffer[-50:]

        # --- Linear velocities (fallback to 0.0 if attributes missing/None)
        self.vx_body, self.vy_body, self.vz_body = world_to_body_xy(self.current_speed.vel_x, 
                                                                    self.current_speed.vel_y, 
                                                                    self.current_speed.vel_z, 
                                                                    self.current_yaw)
        # --- Goal offsets in world frame
        self.dx_world = float(self.current_goal.x - self.current_position.x)
        self.dy_world = float(self.current_goal.y - self.current_position.y)
        self.dz_world = float(self.current_goal.z - self.current_position.z)

        # --- Goal offsets in body frame (yaw-only rotation for egocentric features)
        self.dx_body, self.dy_body, self.dz_body = world_to_body_xy(
            self.dx_world, self.dy_world, self.dz_world, self.current_yaw)

    def compute_observation(self) -> np.ndarray:    
        if self.yaw_err_to_tangent <= 0:
            right_direction = 1
        else:
            right_direction = -1
        r_dir = abs(self._prev_e) - abs(self.yaw_err_to_tangent)

        # self.node.get_logger().info(f"{self.yaw_ref} {self.current_yaw} {self.yaw_err_to_tangent}")

        obs = np.array([
            math.sin(self.current_yaw), math.cos(self.current_yaw),
            math.sin(self.yaw_ref), math.cos(self.yaw_ref),
            self.yaw_err_to_tangent,
            self.vx, self.vy, self.vz,
            self.yaw_rate, 
            r_dir
        ], dtype=np.float32)

        self.obs_log.append({
            "step": int(self.step_counter),
            "current_yaw":self.current_yaw,
            "yaw_ref":self.yaw_ref,
            "yaw_err_to_tangent":self.yaw_err_to_tangent,
            "right_direction": right_direction,
            "yaw_rate": self.yaw_rate,
            "vx": self.vx,
            "vy": self.vy,
            "vz": self.vz})

        if self.step_counter % 50 == 0 and self.step_counter > 0:
            pd.DataFrame(self.obs_log).to_csv(f"rewards/{self.env_tag}_observations.csv", index=False)
        return obs
    
    def compute_reward(self) -> float:
        # Option A (non-negative, bounded, smooth):
        self.absolute_error_sum += abs(self.yaw_err_to_tangent)

        r_dir = abs(self._prev_e) - abs(self.yaw_err_to_tangent)
        self._prev_e = self.yaw_err_to_tangent

        # --- weights (balanced) ---
        w_direction, w_yaw, w_time = 0.0, 1.0, 0.0

        reward = (w_yaw*self.heading_align + w_direction*r_dir)
        if self.heading_align >= 0.99:
            reward += 1

        self.analytic_rewards.append({
            "step": int(self.step_counter),
            "r_heading_yaw": w_yaw * self.heading_align,
            "dir": w_direction*r_dir,
            "step_discount": w_time*self.step_counter,
            "reward": reward})

        if self.step_counter % 50 == 0 and self.step_counter > 0:
            pd.DataFrame(self.analytic_rewards).to_csv(f"rewards/{self.env_tag}_analytic_rewards.csv", index=False)
        
        return float(reward)

    def on_step(self, action) -> None:
        kept_angle_for_30_steps = False
        if len(self.angle_error_buffer) >= 50:
            kept_angle_for_30_steps = True
            for val in self.angle_error_buffer:
                if val < 0.99:
                    kept_angle_for_30_steps = False

        if kept_angle_for_30_steps:
            # self.terminated = True
            # info["success"] = True
            self.bonus_reward = 10
            success = True
            terminated = True
        else: 
            self.bonus_reward = 0
            success = False
            terminated = False

        return success, terminated

    def on_reset(self) -> None:
        self.angle_error_buffer = []
        # Create the timer only once
        if not hasattr(self, "_viz_timer"):
            self._viz_timer = self.node.create_timer(0.5, self._publish_viz)
            self.node.get_logger().info("Viz timer started at 1 Hz.")

    def _publish_viz(self) -> None:
        """Publish the spline as Path/Marker at low rate for RViz."""
        if getattr(self, "waypoint_handler", None) is None:
            return
        try:
            # Reuse cached coeffs/samples in WaypointHandler (no heavy recompute each tick)
            self.waypoint_handler.publish_spline_as_path(samples_per_seg=30, show_orientation=True)
            self.waypoint_handler.publish_spline_as_marker(samples_per_seg=30, width=0.05)
            self.waypoint_handler.publish_waypoints_as_marker()
            self.waypoint_handler.publish_yaw_ref(float(self.current_position.x), 
                                                  float(self.current_position.y), 
                                                  float(self.current_position.z), 
                                                  float(self.yaw_ref))
        except Exception as e:
            self.node.get_logger().warn(f"Viz publish failed: {e}")


    def _publish_action(self, action: np.ndarray) -> None:
        # Thruster mapping: 
        # 0 and 5 back thrusters for surge, 
        # 3 and 8 front horizontal (yaw), 2 and 7 back horizontal (yaw), 
        # 1 and 6 front vertical (heave), 4 and 9 back verical (heave)

        vals = []
        # raw actor outputs
        u0 = float(np.clip(action[0], -1.0, 1.0))           # primary
        u1 = float(np.clip(action[1], -1.0, 1.0)) if action.size > 1 else 0.0  # auxiliary

        # curriculum mixing
        if self.curriculum_stage == 1:
            left, right =  u0, -u0
        elif self.curriculum_stage == 2:
            eps = float(np.clip(self.epsilon, 0.0, 1.0))
            left, right =  u0 + eps*u1,  -u0 + eps*u1
        else:
            left, right =  u0, u1

        # clip AFTER mixing, then scale
        left  = float(np.clip(left,  -1.0, 1.0)) * self.thruster_boost
        right = float(np.clip(right, -1.0, 1.0)) * self.thruster_boost

        # publish to the correct groups (adjust indices if your wiring differs)
        for i, pub in enumerate(self.thruster_pubs):
            msg = FloatStamped()
            msg.header.stamp = self.node.get_clock().now().to_msg()
            if i in (3, 8):          # left / port group
                msg.data = left
                vals.append(msg.data)
            elif i in (2, 7):        # right / starboard group
                msg.data = right
                vals.append(msg.data)
            else:
                msg.data = 0.0
                vals.append(msg.data)
            pub.publish(msg)


# -------- factory for registration ----------
def make_env(**kwargs) -> NeritesMissionPlanning:
    return NeritesMissionPlanning(**kwargs)
