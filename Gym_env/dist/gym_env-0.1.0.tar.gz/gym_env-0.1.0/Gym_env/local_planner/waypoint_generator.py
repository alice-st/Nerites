#!/usr/bin/env python3
# -*- coding: utf-8 -*-
import argparse
import random
import time
from scipy.spatial import cKDTree
from typing import List, Tuple, Sequence, Optional, Dict
import math
import numpy as np
import rclpy
from rclpy.node import Node
from rclpy.qos import QoSProfile, ReliabilityPolicy, DurabilityPolicy, HistoryPolicy

from tf_quaternion.transformations import quaternion_about_axis
from uuv_trajectory_generator.wp_trajectory_generator import WPTrajectoryGenerator

from uuv_control_msgs.msg import WaypointSet as WaypointSetMsg

# add with the other imports
from nav_msgs.msg import Path
from geometry_msgs.msg import PoseStamped, Point
from visualization_msgs.msg import Marker
from uuv_waypoints.waypoint_set import WaypointSet, Waypoint
from .math_utils import *

def transient_local_qos() -> QoSProfile:
    return QoSProfile(
        reliability=ReliabilityPolicy.RELIABLE,
        durability=DurabilityPolicy.TRANSIENT_LOCAL,  # keep last message for late joiners
        history=HistoryPolicy.KEEP_LAST,
        depth=1,
    )

class WaypointHandler:
    """Generate (x, y, z, speed) tuples, convert to WaypointSet, interpolate,
    publish, and (optionally) build Catmull–Rom cubic coefficients per segment.
    """

    def __init__(
        self,
        node: Node,
        env_id: str,
        default_speed: float = 0.5,
        seed: Optional[int] = None,
        uuv_name: str = "x300",
        frame_id: str = "world",
    ):
        self.node = node
        self.env_id = env_id
        self.default_speed = float(default_speed)
        self.frame_id = frame_id
        self.goal_waypoints: List[Tuple[float, float, float, float]] = []
        self.wp_set = WaypointSet()

        if seed is not None:
            random.seed(int(seed))

        # Topic to publish WaypointSet (uuv_control_msgs/WaypointSet)
        self.waypoint_publisher_topic = f"/{env_id}/waypoints"
        self._waypoints_pub = self.node.create_publisher(WaypointSetMsg, self.waypoint_publisher_topic, transient_local_qos())
        
        self.waypoint_marker_publisher_topic = f"/{env_id}/waypoints_markers"
        self.waypoint_marker_publisher = self.node.create_publisher(Marker, self.waypoint_marker_publisher_topic, transient_local_qos())

        self.path_piblisher_topic = f"/{env_id}/spline_path"
        self._path_pub = self.node.create_publisher(Path, self.path_piblisher_topic, transient_local_qos())
        
        self.marker_publisher_topic = f"/{env_id}/spline_marker"
        self._marker_pub = self.node.create_publisher(Marker, self.marker_publisher_topic, transient_local_qos())

        self.lookahead_publisher_path_topic = f"/{env_id}/lookahead_path"
        self._la_path_pub = self.node.create_publisher(Path, self.lookahead_publisher_path_topic, transient_local_qos())

        self.lookahead_publisher_marker_topic = f"/{env_id}/lookahead_marker"
        self._la_marker_pub = self.node.create_publisher(Marker, self.lookahead_publisher_marker_topic, transient_local_qos())

        self.yaw_ref_pose_topic   = f"/{env_id}/yaw_ref"
        self.yaw_ref_marker_topic = f"/{env_id}/yaw_ref_marker"
        self._yaw_pose_pub   = self.node.create_publisher(PoseStamped, self.yaw_ref_pose_topic,   transient_local_qos())
        self._yaw_marker_pub = self.node.create_publisher(Marker,      self.yaw_ref_marker_topic, transient_local_qos())

        # Optional: storage for samples / KD-tree for fast distance queries
        self._samples_xyz: Optional[np.ndarray] = None
        self._kdtree = None

        # Catmull–Rom coefficients cache
        self._cr_coeffs: Optional[List[Dict[str, float]]] = None

    # ---------------- Waypoint Generators ---------------- #
    def build_from_list(
        self,
        points: Sequence[Tuple[float, float, float]],
        speed: Optional[float] = None,
    ) -> List[Tuple[float, float, float, float]]:
        """Turn list of (x, y, z) into (x, y, z, speed)."""
        spd = self.default_speed if speed is None else float(speed)
        self.goal_waypoints = [(float(x), float(y), float(z), spd) for (x, y, z) in points]
        
        return self.goal_waypoints

    def build_random(
        self,
        initial_robot_pose,
        n: int = 5,
        r_xy: float = 20.0,
        r_z: float = 5.0,
        round_to: int = 2,
        speed: Optional[float] = None,
        *,
        min_xy: float = 5.0,        # <-- NEW: minimum XY distance from the start
        min_sep: float = 3.0,       # <-- NEW: minimum 3D separation from the previous waypoint
        tries_per_point: int = 200  # safety to avoid infinite loops
    ) -> List[Tuple[float, float, float, float]]:
        """
        Generate n (x, y, z, speed) waypoints around the initial pose such that:
          - each waypoint is at least `min_xy` meters away in XY from the initial pose,
          - consecutive waypoints are at least `min_sep` meters apart in 3D,
          - z offsets stay within [-r_z, +r_z].
        The first waypoint is exactly the initial pose.
        """
        spd = self.default_speed if speed is None else float(speed)
        cx, cy, cz = float(initial_robot_pose.x), float(initial_robot_pose.y), float(initial_robot_pose.z)

        self.goal_waypoints: List[Tuple[float, float, float, float]] = []
        # Waypoint 0 = initial position
        self.goal_waypoints.append((round(cx, round_to), round(cy, round_to), round(cz, round_to), spd))

        # Generate remaining waypoints
        for k in range(int(n) - 1):
            cur_min_xy = float(min_xy)
            cur_min_sep = float(min_sep)

            for attempt in range(tries_per_point):
                # Sample uniformly in an annulus [cur_min_xy, r_xy] in XY
                R = np.random.uniform(cur_min_xy, float(r_xy))
                theta = np.random.uniform(-np.pi, np.pi)
                dx = R * np.cos(theta)
                dy = R * np.sin(theta)

                # Sample Z within bounds
                dz = np.random.uniform(-float(r_z), float(r_z))

                x = round(cx + dx, round_to)
                y = round(cy + dy, round_to)
                z = round(cz + dz, round_to)

                # Enforce separation from the previous waypoint (3D)
                last_xyz = np.array(self.goal_waypoints[-1][:3], dtype=float)
                if dist3(np.array([x, y, z]), last_xyz) < cur_min_sep:
                    continue

                # Also ensure it’s not too close in XY to the START (cx, cy)
                if np.hypot(x - cx, y - cy) < cur_min_xy:
                    continue

                self.goal_waypoints.append((x, y, z, spd))
                break
            else:
                # If we failed to place a point after many tries, relax constraints a bit and retry once more
                cur_min_xy *= 0.7
                cur_min_sep *= 0.7
                for attempt in range(tries_per_point):
                    R = np.random.uniform(cur_min_xy, float(r_xy))
                    theta = np.random.uniform(-np.pi, np.pi)
                    dx = R * np.cos(theta)
                    dy = R * np.sin(theta)
                    dz = np.random.uniform(-float(r_z), float(r_z))
                    x = round(cx + dx, round_to)
                    y = round(cy + dy, round_to)
                    z = round(cz + dz, round_to)
                    last_xyz = np.array(self.goal_waypoints[-1][:3], dtype=float)
                    if dist3(np.array([x, y, z]), last_xyz) < cur_min_sep:
                        continue
                    if np.hypot(x - cx, y - cy) < cur_min_xy:
                        continue
                    self.goal_waypoints.append((x, y, z, spd))
                    break
                else:
                    # As a final fallback, place something at max radius along a new angle
                    theta = np.random.uniform(-np.pi, np.pi)
                    x = round(cx + float(r_xy) * np.cos(theta), round_to)
                    y = round(cy + float(r_xy) * np.sin(theta), round_to)
                    z = round(cz + np.clip(np.random.uniform(-float(r_z), float(r_z)), -r_z, r_z), round_to)
                    self.goal_waypoints.append((x, y, z, spd))

        # Invalidate caches when waypoints change
        self._samples_xyz = None
        self._kdtree = None
        self._cr_coeffs = None
        self.to_waypointset()
        return self.goal_waypoints

    # ---------------- Catmull–Rom cubic coefficients ---------------- #
    def build_catmull_rom_coeffs(self, closed: bool = False) -> List[Dict[str, float]]:
        """Compute and cache Catmull–Rom cubic coefficients per segment from current tuples.

        Returns a list of dicts with ax,bx,cx,dx, ay,by,cy,dy, az,bz,cz,dz and indices.
        """
        if len(self.goal_waypoints) < 2:
            raise RuntimeError("Need at least 2 waypoints to build coefficients")

        XYZ = np.array([(x, y, z) for x, y, z, _ in self.goal_waypoints], dtype=float)
        N = XYZ.shape[0]

        # If closed path requested, append first point at end if not already
        if closed:
            if not np.allclose(XYZ[0], XYZ[-1]):
                XYZ = np.vstack([XYZ, XYZ[0]])
            N = XYZ.shape[0]

        def idx(i: int) -> int:
            if closed:
                return i % N
            return min(max(i, 0), N - 1)

        coeffs: List[Dict[str, float]] = []
        for i in range(N - 1):
            P0, P1, P2, P3 = XYZ[idx(i - 1)], XYZ[i], XYZ[i + 1], XYZ[idx(i + 2)]
            a, b, c, d = catmull_rom_coeffs(P0, P1, P2, P3)
            coeffs.append({
                "ax": float(a[0]), "bx": float(b[0]), "cx": float(c[0]), "dx": float(d[0]),
                "ay": float(a[1]), "by": float(b[1]), "cy": float(c[1]), "dy": float(d[1]),
                "az": float(a[2]), "bz": float(b[2]), "cz": float(c[2]), "dz": float(d[2]),
                "from_idx": int(i), "to_idx": int(i + 1)
            })

        self._cr_coeffs = coeffs

        return coeffs

    def sample_catmull_rom(self, samples_per_seg: int = 20, closed: bool = False) -> np.ndarray:
        """Sample the Catmull–Rom spline built from current tuples. Returns (M,3) array."""
        if self._cr_coeffs is None:
            self.build_catmull_rom_coeffs(closed=closed)
        coeffs = self._cr_coeffs or []
        all_samples = []
        for k, co in enumerate(coeffs):
            a = np.array([co["ax"], co["ay"], co["az"]], dtype=float)
            b = np.array([co["bx"], co["by"], co["bz"]], dtype=float)
            c = np.array([co["cx"], co["cy"], co["cz"]], dtype=float)
            d = np.array([co["dx"], co["dy"], co["dz"]], dtype=float)
            # avoid duplicating last point when stitching segments
            ts = np.linspace(0.0, 1.0, samples_per_seg, endpoint=(k == len(coeffs) - 1))
            seg = np.vstack([eval_cubic(a, b, c, d, t) for t in ts])
            all_samples.append(seg)
        samples = np.vstack(all_samples) if all_samples else np.zeros((0, 3))
        # cache samples and KD-tree for fast queries
        self._samples_xyz = samples
        self._kdtree = cKDTree(samples)
        return samples

    # ---------------------------------------------------------- #
    # ---------------- Distance queries ------------------------ #
    # ---------------------------------------------------------- #

    def distance_to_spline_coeffs(self, p_xyz: np.ndarray) -> Tuple[float, np.ndarray, int, float]:
        """Global closest point over all cubic segments (uses built coefficients).
        Returns (distance, closest_xyz, segment_index, t)."""
        
        if self._cr_coeffs is None:
            raise RuntimeError("No Catmull–Rom coefficients. Call build_catmull_rom_coeffs() first.")
        
        p = np.asarray(p_xyz, float)
        best = (np.inf, np.zeros(3), -1, 0.0)

        for i, co in enumerate(self._cr_coeffs):
            dist, q, t = self.closest_point_on_cubic_segment(p, co)
            if dist < best[0]:
                best = (dist, q, i, t)
        
        return best

    def closest_point_on_cubic_segment(self, p: np.ndarray, co: Dict[str, float]) -> Tuple[float, np.ndarray, float]:
        """Refine closest point on a single cubic segment using Newton iterations.
        Returns (distance, closest_xyz, t in [0,1])."""
        a = np.array([co["ax"], co["ay"], co["az"]], dtype=float)
        b = np.array([co["bx"], co["by"], co["bz"]], dtype=float)
        c = np.array([co["cx"], co["cy"], co["cz"]], dtype=float)
        d = np.array([co["dx"], co["dy"], co["dz"]], dtype=float)
        p = np.asarray(p, float)

        # coarse init
        ts = np.linspace(0.0, 1.0, 25)
        rs = np.vstack([eval_cubic(a, b, c, d, t) for t in ts])
        d2 = np.sum((rs - p) ** 2, axis=1)
        t = float(ts[int(np.argmin(d2))])
        # refine
        for _ in range(12):
            r = eval_cubic(a, b, c, d, t)
            rp = eval_cubic_der(a, b, c, t)
            rpp = 6 * a * t + 2 * b
            g = np.dot(r - p, rp)
            h = np.dot(rp, rp) + np.dot(r - p, rpp)
            if h == 0:
                break
            t = float(np.clip(t - g / h, 0.0, 1.0))
        q = eval_cubic(a, b, c, d, t)
        
        return float(np.linalg.norm(q - p)), q, t

    # ---------------------------------------------------------- #
    # ---------------- Helpers --------------------------------- #
    # ---------------------------------------------------------- #

    def _yaw_from_tangent(self, tx: float, ty: float) -> float:
        return float(np.arctan2(ty, tx))

    def _quat_about_z(self, yaw: float):
        # returns (x,y,z,w) to match geometry_msgs/Quaternion layout
        qx, qy, qz, qw = quaternion_about_axis(yaw, [0, 0, 1])
        return qx, qy, qz, qw

    def points_ahead_of_vehicle(self, p_xyz, current_yaw=None, ds=2.0, n=5, with_yaw=True, closed=False):
        """
        Return n points (x,y,z[,yaw]) ~ds meters apart, robust at boundaries
        and when tangents are tiny. Falls back to the direction with more arc-length.
        """
        if self._cr_coeffs is None:
            self.build_catmull_rom_coeffs(closed=closed)
        coeffs = self._cr_coeffs or []
        if not coeffs:
            return []

        # 1) Closest point (i,t)
        _, _, seg_idx, t = self.distance_to_spline_coeffs(np.asarray(p_xyz, float))
        i = int(seg_idx); tt = float(t)

        # 2) Initial direction from heading, then choose by available arc-length if needed
        direction = +1
        if current_yaw is not None and 0 <= i < len(coeffs):
            tvec = tan_at(coeffs, i, tt)
            hx, hy = math.cos(current_yaw), math.sin(current_yaw)
            direction = +1 if (hx * tvec[0] + hy * tvec[1]) >= 0.0 else -1

        # How much arc do we have forward/back for the next N samples?
        want_len = ds * (n + 1)  # include kickoff margin
        fwd_len = arc_available(coeffs, i, tt, +1, want_len, closed)
        bwd_len = arc_available(coeffs, i, tt, -1, want_len, closed)

        if not closed:
            # if our heading-picked direction has <30% of the other, flip
            if direction > 0 and fwd_len < 0.3 * max(bwd_len, 1e-6):
                direction = -1
            elif direction < 0 and bwd_len < 0.3 * max(fwd_len, 1e-6):
                direction = +1
            # If both are tiny near a degenerate start, we’ll still try to kick off below.

        # 3) Kick off away from boundary (and away from zero-speed spots)
        kickoff = max(0.25 * ds, 0.20)  # at least 20 cm
        i, tt, pos0 = advance(coeffs, i, tt, kickoff, direction, closed)

        # If still not moving, try mid-segment as an escape hatch
        try_hops = 0
        while try_hops < 3:
            tvec = tan_at(coeffs, i, tt)
            if float(np.linalg.norm(tvec)) > 1e-6:
                break
            try_hops += 1
            # jump to the middle of current/next segment depending on direction
            if direction > 0:
                if tt >= 0.99 and i < len(coeffs) - 1:
                    i += 1; tt = 0.5
                else:
                    tt = 0.5
            else:
                if tt <= 0.01 and i > 0:
                    i -= 1; tt = 0.5
                else:
                    tt = 0.5
            pos0 = pos_at(coeffs, i, tt)

        # 4) Collect n samples
        pts = []
        cur_i, cur_t = i, tt
        for _ in range(int(n)):
            cur_i, cur_t, pos = advance(coeffs, cur_i, cur_t, ds, direction, closed)
            if with_yaw:
                tvec = tan_at(coeffs, cur_i, cur_t)
                yaw = float(math.atan2(tvec[1], tvec[0]))
                pts.append((float(pos[0]), float(pos[1]), float(pos[2]), yaw))
            else:
                pts.append((float(pos[0]), float(pos[1]), float(pos[2])))

        # Optional: publish for RViz (make sure your publisher expects xyz or xyzyaw)
        try:
            self.publish_points_ahead(pts, with_yaw=with_yaw)
        except Exception:
            pass

        return pts

    # ---------------------------------------------------------- #
    # ---------------- Conversions + Publishing  --------------- #
    # ---------------------------------------------------------- #

    def to_waypointset(self) -> WaypointSet:
        """Build and return a WaypointSet (requires uuv_waypoints)."""
        self.wp_set = WaypointSet(inertial_frame_id=self.frame_id)
        for x, y, z, s in self.goal_waypoints:
            self.wp_set.add_waypoint(Waypoint(float(x), float(y), float(z), float(s)))
        return self.wp_set  # ensure the set is returned

    def publish_waypoints(self):
        """Publish the current WaypointSet to the configured topic with transient QoS."""
        if self.wp_set is None or self.wp_set.num_waypoints == 0:
            self.node.get_logger().warning("No waypoints to publish")
            return

        msg = self.wp_set.to_message(self.node.get_clock().now())
        msg.header.frame_id = self.frame_id
        self._waypoints_pub.publish(msg)
        self.node.get_logger().debug(
            f"Publishing WaypointSet with {self.wp_set.num_waypoints} waypoints to {self.waypoint_publisher_topic}"
        )

    def publish_waypoints_as_marker(self, width: float = 0.05):
        """
        Publish the Catmull–Rom spline as a LINE_STRIP Marker (lightweight polyline).
        """

        marker = Marker()
        marker.header.stamp = self.node.get_clock().now().to_msg()
        marker.header.frame_id = self.frame_id
        marker.ns = "waypoint"
        marker.id = 1
        marker.type = Marker.SPHERE_LIST
        marker.action = Marker.ADD
        marker.scale.x = float(0.50)   # line thickness (meters)
        marker.scale.y = float(0.50)
        marker.scale.z = float(0.50)

        # color RGBA (keep visible). RViz default background is dark:
        marker.color.r = 1.0
        marker.color.g = 0.0
        marker.color.b = 0.0
        marker.color.a = 1.0
        marker.lifetime.sec = 0  # forever

        marker.points = []
        for waypoint in self.goal_waypoints:
            pt = Point()
            pt.x, pt.y, pt.z = waypoint[0], waypoint[1], waypoint[2]
            marker.points.append(pt)

        self.waypoint_marker_publisher.publish(marker)
    
    def publish_spline_as_path(self, samples_per_seg: int = 20, show_orientation: bool = True):
        """
        Publish the Catmull–Rom spline as nav_msgs/Path. If show_orientation=True,
        orientations follow the spline tangent.
        """
        if self._cr_coeffs is None:
            self.build_catmull_rom_coeffs(closed=False)
        samples = self.sample_catmull_rom(samples_per_seg=samples_per_seg)

        path = Path()
        path.header.stamp = self.node.get_clock().now().to_msg()
        path.header.frame_id = self.frame_id

        # iterate segments to get tangent for orientation
        for seg_idx, co in enumerate(self._cr_coeffs):
            a = np.array([co["ax"], co["ay"], co["az"]], float)
            b = np.array([co["bx"], co["by"], co["bz"]], float)
            c = np.array([co["cx"], co["cy"], co["cz"]], float)
            d = np.array([co["dx"], co["dy"], co["dz"]], float)

            # same t grid used in sample_catmull_rom (endpoint only for last seg)
            ts = np.linspace(0.0, 1.0, samples_per_seg,
                             endpoint=(seg_idx == len(self._cr_coeffs) - 1))
            for t in ts:
                pos = ((a*t + b)*t + c)*t + d
                pose = PoseStamped()
                pose.header.frame_id = self.frame_id
                pose.pose.position.x, pose.pose.position.y, pose.pose.position.z = map(float, pos)

                if show_orientation:
                    # tangent r'(t) = 3a t^2 + 2b t + c  → yaw around Z
                    tan = (3*a*t + 2*b)*t + c
                    yaw = self._yaw_from_tangent(float(tan[0]), float(tan[1]))
                    qx, qy, qz, qw = self._quat_about_z(yaw)
                    pose.pose.orientation.x, pose.pose.orientation.y = qx, qy
                    pose.pose.orientation.z, pose.pose.orientation.w = qz, qw

                path.poses.append(pose)

        self._path_pub.publish(path)

    def publish_spline_as_marker(self, samples_per_seg: int = 20, width: float = 0.05):
        """
        Publish the Catmull–Rom spline as a LINE_STRIP Marker (lightweight polyline).
        """
        if self._cr_coeffs is None:
            self.build_catmull_rom_coeffs(closed=False)
        samples = self.sample_catmull_rom(samples_per_seg=samples_per_seg)

        marker = Marker()
        marker.header.stamp = self.node.get_clock().now().to_msg()
        marker.header.frame_id = self.frame_id
        marker.ns = "spline"
        marker.id = 0
        marker.type = Marker.LINE_STRIP
        marker.action = Marker.ADD
        marker.scale.x = float(width)   # line thickness (meters)
        # color RGBA (keep visible). RViz default background is dark:
        marker.color.r = 0.2
        marker.color.g = 0.9
        marker.color.b = 0.2
        marker.color.a = 1.0
        marker.lifetime.sec = 0  # forever

        marker.points = []
        for p in samples:
            pt = Point()
            pt.x, pt.y, pt.z = map(float, p)
            marker.points.append(pt)

        self._marker_pub.publish(marker)

    def publish_points_ahead(self, pts, with_yaw):
        """
        Compute and publish N points ahead of the vehicle along the spline.

        Publishes:
          - nav_msgs/Path  at  <env>/lookahead_path   (poses oriented by yaw)
          - Marker (SPHERE_LIST) at <env>/lookahead_marker (green spheres)

        Returns list of (x,y,z,yaw) if with_yaw else (x,y,z).
        """

        sphere_diam: float = 0.25
        
        # ---- Path (poses with orientation) ----
        path = Path()
        path.header.stamp = self.node.get_clock().now().to_msg()
        path.header.frame_id = self.frame_id

        for item in pts:
            if with_yaw:
                x, y, z, yaw = item
            else:
                x, y, z = item
                yaw = 0.0
            ps = PoseStamped()
            ps.header = path.header
            ps.pose.position.x = float(x)
            ps.pose.position.y = float(y)
            ps.pose.position.z = float(z)
            qx, qy, qz, qw = self._quat_about_z(float(yaw))
            ps.pose.orientation.x = qx
            ps.pose.orientation.y = qy
            ps.pose.orientation.z = qz
            ps.pose.orientation.w = qw
            path.poses.append(ps)

        self._la_path_pub.publish(path)

        # ---- Marker (spheres at each point) ----
        m = Marker()
        m.header = path.header
        m.ns = "lookahead"
        m.id = 0
        m.type = Marker.SPHERE_LIST
        m.action = Marker.ADD
        m.scale.x = float(sphere_diam)
        m.scale.y = float(sphere_diam)
        m.scale.z = float(sphere_diam)
        m.color.r = 0.2
        m.color.g = 0.9
        m.color.b = 0.2
        m.color.a = 1.0
        m.lifetime.sec = 0

        m.points = []
        for item in pts:
            x, y, z = (item[:3] if with_yaw else item)
            pt = Point()
            pt.x = float(x); pt.y = float(y); pt.z = float(z)
            m.points.append(pt)

        self._la_marker_pub.publish(m)

    def publish_yaw_ref(self, x: float, y: float, z: float, yaw_ref: float):
        """Publish a PoseStamped + ARROW marker showing yaw_ref at (x,y,z)."""
        # PoseStamped
        pose = PoseStamped()
        pose.header.stamp = self.node.get_clock().now().to_msg()
        pose.header.frame_id = self.frame_id
        pose.pose.position.x = float(x)
        pose.pose.position.y = float(y)
        pose.pose.position.z = float(z)
        qx, qy, qz, qw = self._quat_about_z(float(yaw_ref))  # yaw-only orientation
        pose.pose.orientation.x = qx
        pose.pose.orientation.y = qy
        pose.pose.orientation.z = qz
        pose.pose.orientation.w = qw
        self._yaw_pose_pub.publish(pose)

        # Marker (arrow)
        m = Marker()
        m.header = pose.header
        m.ns = "yaw_ref"
        m.id = 0
        m.type = Marker.ARROW
        m.action = Marker.ADD
        m.pose = pose.pose
        m.scale.x = 1.0   # arrow length (m)
        m.scale.y = 0.05  # shaft diameter
        m.scale.z = 0.05  # head diameter
        m.color.r = 0.1
        m.color.g = 0.9
        m.color.b = 0.2
        m.color.a = 1.0
        m.lifetime.sec = 0
        self._yaw_marker_pub.publish(m)