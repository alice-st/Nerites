#!/usr/bin/env python3
import os, sys, datetime, multiprocessing as mp
from typing import Callable
import gymnasium as gym
import numpy as np
import torch
import torch.nn as nn
from stable_baselines3 import SAC
from stable_baselines3.common.vec_env import SubprocVecEnv, DummyVecEnv, VecNormalize
from stable_baselines3.common.callbacks import EvalCallback, BaseCallback, CallbackList
import envs  # noqa: F401 – make sure envs package is importable

# ---- EXACT ID that is registered ----
ENV_ID = "Nerites_mission_planning-v1"
NUM_PARALLEL_ENVS = 5
HEADLESS_TRAIN = True

# For callback evaluation during training, keep it headless
HEADLESS_EVAL_CB = True

# For the post-training demo (optional), you can still set GUI later if you want
HEADLESS_EVAL = False  # only used in the post-training block

LOG_DIR = "Training_data/sac_logs"
BEST_MODEL_SAVE_PATH = os.path.join(LOG_DIR, "0.5_meters")
MODEL_PATH = os.path.join(BEST_MODEL_SAVE_PATH, "best_model2.zip")
VECNORM_PATH = os.path.join(BEST_MODEL_SAVE_PATH, "vecnormalize.pkl")

def make_env_fn(rank: int):
    def _init():
        repo_root = os.path.dirname(os.path.abspath(__file__))
        if repo_root not in sys.path:
            sys.path.insert(0, repo_root)
        return gym.make(
            ENV_ID,
            env_id=f"training_env{rank}",
            headless=HEADLESS_TRAIN,
            render_mode=None,
        )
    return _init

def make_eval_env_fn(headless: bool, env_id: str):
    """Factory to create eval envs either headless (for callback) or GUI (for post-run demo)."""
    def _init():
        repo_root = os.path.dirname(os.path.abspath(__file__))
        if repo_root not in sys.path:
            sys.path.insert(0, repo_root)
        import envs  # noqa: F401
        return gym.make(ENV_ID, env_id=env_id, headless=headless, render_mode=None)
    return _init

def linear_schedule(initial_value: float) -> Callable[[float], float]:
    def func(progress_remaining: float) -> float:
        return progress_remaining * initial_value
    return func

class SaveVecNormalizeCallback(BaseCallback):
    """When EvalCallback finds a new best model, also save VecNormalize stats."""
    def __init__(self, save_path: str, verbose: int = 0):
        super().__init__(verbose)
        self.save_path = save_path

    def _on_step(self) -> bool:
        vec_norm = self.model.get_vec_normalize_env()  # type: ignore[attr-defined]
        if vec_norm is not None:
            vec_norm.save(self.save_path)
            if self.verbose > 0:
                print(f"[Callback] Saved VecNormalize to {self.save_path}")
        return True

def main():
    mp.set_start_method("spawn", force=True)
    os.environ.setdefault("OMP_NUM_THREADS", "1")
    os.makedirs(LOG_DIR, exist_ok=True)
    os.makedirs(BEST_MODEL_SAVE_PATH, exist_ok=True)

    # -----------------------------
    # TRAIN (parallel envs)
    # -----------------------------
    print(f"Creating {NUM_PARALLEL_ENVS} parallel environments for training...")
    train_subproc = SubprocVecEnv([make_env_fn(i) for i in range(NUM_PARALLEL_ENVS)],
                                  start_method="spawn")

    # VecNormalize for training
    if os.path.exists(VECNORM_PATH):
        train_env = VecNormalize.load(VECNORM_PATH, train_subproc)
        train_env.training = True
        train_env.norm_reward = True
    else:
        train_env = VecNormalize(train_subproc, norm_obs=True, norm_reward=True)

    policy_kwargs = dict(net_arch=dict(pi=[256, 256], qf=[256, 256]), activation_fn=nn.ReLU)

    if os.path.exists(MODEL_PATH):
        print(f"--- Loading existing model from {MODEL_PATH} ---")
        model = SAC.load(MODEL_PATH, env=train_env)
        model.tensorboard_log = LOG_DIR
    else:
        model = SAC(
            "MlpPolicy", train_env,
            learning_rate=linear_schedule(3e-4),
            buffer_size=1_000_000,
            learning_starts=1_000,
            batch_size=256,
            tau=0.01, gamma=0.99,
            train_freq=(1, "step"), gradient_steps=1,
            ent_coef="auto",
            policy_kwargs=policy_kwargs,
            verbose=1, tensorboard_log=LOG_DIR,
        )

    # -----------------------------
    # EVAL CALLBACK (runs during training)
    # -----------------------------
    # Build one persistent (headless) eval env and share obs_rms with training.
    eval_dummy_cb = DummyVecEnv([make_eval_env_fn(HEADLESS_EVAL_CB, env_id="evaluation_env_cb")])
    eval_env_cb = VecNormalize(eval_dummy_cb, norm_obs=True, norm_reward=False)
    eval_env_cb.training = False
    eval_env_cb.norm_reward = False
    # Share normalization stats from training to evaluation:
    if isinstance(train_env, VecNormalize):
        eval_env_cb.obs_rms = train_env.obs_rms

    # When a new best is found, save both the model and the VecNormalize file
    save_vec_cb = SaveVecNormalizeCallback(VECNORM_PATH, verbose=0)

    eval_freq = max(10_000 // NUM_PARALLEL_ENVS, 1)  # adjust as you like
    eval_cb = EvalCallback(
        eval_env_cb,
        best_model_save_path=BEST_MODEL_SAVE_PATH,
        log_path=LOG_DIR,
        n_eval_episodes=5,
        eval_freq=eval_freq,
        deterministic=True,
        render=False,
        callback_on_new_best=save_vec_cb,
    )

    cb_list = CallbackList([eval_cb])

    print("Starting training...")
    run_name = "SAC" + datetime.datetime.now().strftime("%Y%m%d-%H%M%S")
    try:
        model.learn(
            total_timesteps=500_000,
            callback=cb_list,          # <-- evaluation during training
            log_interval=20,
            tb_log_name=run_name,
            reset_num_timesteps=False,
            progress_bar=True,
        )
    finally:
        print("Training stopped. Saving model + VecNormalize and cleaning up training env...")
        # Save final model and stats
        model.save(os.path.join(LOG_DIR, f"sac_final_{datetime.datetime.now().strftime('%Y%m%d-%H%M%S')}.zip"))
        if isinstance(train_env, VecNormalize):
            train_env.save(VECNORM_PATH)
        # Close eval env from callback and training env
        try:
            eval_env_cb.close()
        except Exception:
            pass
        train_env.close()  # closes SubprocVecEnv + Gazebo

    # -----------------------------
    # OPTIONAL: POST-TRAINING EVALUATION (single env, can show GUI)
    # -----------------------------
    print("Starting post-training evaluation (single environment)...")
    eval_dummy = DummyVecEnv([make_eval_env_fn(HEADLESS_EVAL, env_id="evaluation_env_999")])
    if os.path.exists(VECNORM_PATH):
        eval_env = VecNormalize.load(VECNORM_PATH, eval_dummy)
    else:
        eval_env = VecNormalize(eval_dummy, norm_obs=True, norm_reward=False)
    eval_env.training = False
    eval_env.norm_reward = False

    # Keep obs stats aligned (use saved stats if present)
    if hasattr(eval_env, "obs_rms") and isinstance(eval_env_cb, VecNormalize):
        # Not strictly required if you loaded from file, but safe:
        eval_env.obs_rms = eval_env.obs_rms

    # Sanity check obs shape
    obs = eval_env.reset()
    print(f"[Eval] Obs shape: {np.array(obs).shape}")

    n_eval_episodes = 5
    ep_len = 750
    returns = []
    for ep in range(n_eval_episodes):
        obs = eval_env.reset()
        ep_ret = 0.0
        for _ in range(ep_len):
            action, _ = model.predict(obs, deterministic=True)
            obs, rewards, dones, infos = eval_env.step(action)
            ep_ret += float(rewards[0])
            if bool(dones[0]):
                break
        returns.append(ep_ret)
        print(f"[Eval] Episode {ep+1}/{n_eval_episodes} return: {ep_ret:.3f}")

    if returns:
        mean_ret = float(np.mean(returns))
        std_ret = float(np.std(returns))
        print(f"[Eval] Mean return over {n_eval_episodes} episodes: {mean_ret:.3f} ± {std_ret:.3f}")

    eval_env.close()
    print("Evaluation finished and env closed.")

if __name__ == "__main__":
    main()
