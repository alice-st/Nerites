#!/usr/bin/env python3
import os, sys, datetime
from typing import Callable, Tuple, List
import gymnasium as gym
import numpy as np
import torch
import torch.nn as nn
from stable_baselines3 import SAC
from stable_baselines3.common.vec_env import DummyVecEnv, VecNormalize
import envs  # ensure env ID is registered

# ---- EXACT ID that is registered ----
ENV_ID = "Nerites_mission_planning-v1"

# Visibility
HEADLESS_TRAIN = True
HEADLESS_EVAL = False  # set True if you don't want GUI for eval

# Paths
LOG_DIR = "Training_data/sac_logs"
BEST_MODEL_SAVE_PATH = os.path.join(LOG_DIR, "0.5_meters")
FINAL_MODEL_PATH = os.path.join(BEST_MODEL_SAVE_PATH, "final_model.zip")
VECNORM_PATH = os.path.join(BEST_MODEL_SAVE_PATH, "vecnormalize.pkl")

TOTAL_TIMESTEPS = 500_000
EVAL_EPISODES = 10
EVAL_EP_LEN = 750
DETERMINISTIC_EVAL = True  # SAC eval is typically deterministic

def make_env_fn(env_tag: str, *, headless: bool, render_mode=None):
    """Returns a factory that builds a single Gymnasium env instance."""
    def _init():
        repo_root = os.path.dirname(os.path.abspath(__file__))
        if repo_root not in sys.path:
            sys.path.insert(0, repo_root)
        # Import ensures registration if env registers at import time
        import envs  # noqa: F401
        return gym.make(
            ENV_ID,
            env_id=env_tag,
            headless=headless,
            render_mode=render_mode,
        )
    return _init

def linear_schedule(initial_value: float) -> Callable[[float], float]:
    def func(progress_remaining: float) -> float:
        return progress_remaining * initial_value
    return func

def attach_or_create_vecnorm(venv: DummyVecEnv, *, load_path: str, train: bool, norm_rew_when_train=True) -> VecNormalize:
    """Load VecNormalize stats if present, else create a new one."""
    if os.path.exists(load_path):
        vec = VecNormalize.load(load_path, venv)
    else:
        vec = VecNormalize(venv, norm_obs=True, norm_reward=bool(train))
    vec.training = bool(train)
    vec.norm_reward = bool(train and norm_rew_when_train)
    return vec

def evaluate_model(
    model: SAC,
    vec_env: VecNormalize,
    *,
    n_episodes: int,
    max_ep_len: int,
    deterministic: bool = True
) -> Tuple[List[float], float]:
    """Run episodes and return per-episode returns and mean."""
    returns: List[float] = []
    for _ in range(n_episodes):
        obs = vec_env.reset()
        ep_ret = 0.0
        for _ in range(max_ep_len):
            action, _ = model.predict(obs, deterministic=deterministic)
            obs, rewards, dones, infos = vec_env.step(action)
            ep_ret += float(np.mean(rewards))
            if np.any(dones):
                break
        returns.append(ep_ret)
    return returns, float(np.mean(returns)) if returns else 0.0

def main():
    # Single-process, single-env
    os.environ.setdefault("OMP_NUM_THREADS", "1")
    os.makedirs(LOG_DIR, exist_ok=True)
    os.makedirs(BEST_MODEL_SAVE_PATH, exist_ok=True)

    # ----------------------------
    # 1) TRAIN (single env)
    # ----------------------------
    print("Creating a single training environment (no subprocesses)...")
    train_dummy = DummyVecEnv([make_env_fn("training_env0", headless=HEADLESS_TRAIN, render_mode=None)])

    # Load/create VecNormalize for training
    # (If you want fresh stats each run, delete VECNORM_PATH before training.)
    train_env = attach_or_create_vecnorm(train_dummy, load_path=VECNORM_PATH, train=True, norm_rew_when_train=True)

    policy_kwargs = dict(net_arch=dict(pi=[256, 256], qf=[256, 256]), activation_fn=nn.ReLU)

    # if os.path.exists(FINAL_MODEL_PATH):
    #     print(f"--- Loading existing model from {FINAL_MODEL_PATH} ---")
    #     model = SAC.load(FINAL_MODEL_PATH, env=train_env)
    #     model.tensorboard_log = LOG_DIR
    #     reset_num_timesteps = False
    # else:
    model = SAC(
        "MlpPolicy",
        train_env,
        learning_rate=linear_schedule(3e-4),
        buffer_size=1_000_000,
        learning_starts=1_000,
        batch_size=256,
        tau=0.01,
        gamma=0.99,
        train_freq=(1, "step"),
        gradient_steps=1,
        ent_coef="auto",
        policy_kwargs=policy_kwargs,
        verbose=1,
        tensorboard_log=LOG_DIR,
    )
    reset_num_timesteps = True  # first run

    run_name = "SAC" + datetime.datetime.now().strftime("%Y%m%d-%H%M%S")
    print("Starting training...")
    try:
        model.learn(
            total_timesteps=TOTAL_TIMESTEPS,
            callback=None,                 # <-- no live evaluation
            log_interval=20,
            tb_log_name=run_name,
            reset_num_timesteps=reset_num_timesteps,
            progress_bar=True,
        )
    finally:
        print("Training finished. Saving model + VecNormalize and cleaning up training env...")
        model.save(FINAL_MODEL_PATH)
        if isinstance(train_env, VecNormalize):
            train_env.save(VECNORM_PATH)
        # Close training env before starting any evaluation env
        train_env.close()

    # ----------------------------
    # 2) EVALUATE AFTER TRAINING
    # ----------------------------
    print("Spawning a fresh evaluation env (single, no subprocesses)...")
    eval_dummy = DummyVecEnv([make_env_fn("evaluation_env_999", headless=HEADLESS_EVAL, render_mode=None)])

    # Load VecNormalize and set to eval mode
    if os.path.exists(VECNORM_PATH):
        eval_env = VecNormalize.load(VECNORM_PATH, eval_dummy)
    else:
        # If stats are missing (first-ever run), still wrap so interfaces match
        eval_env = VecNormalize(eval_dummy, norm_obs=True, norm_reward=False)
    eval_env.training = False
    eval_env.norm_reward = False  # don't normalize reward at eval

    # Important: If we used a training env earlier, ensure obs_rms is set.
    # (VecNormalize.load should already populate it; line below is a belt-and-braces pattern.)
    # eval_env.obs_rms already loaded with stats.

    # You can reuse the in-memory model for prediction even after closing the train env
    # (SB3 predict uses the policy; env is only needed for learn()).
    print(f"Evaluating for {EVAL_EPISODES} episode(s), max length {EVAL_EP_LEN}...")
    ep_returns, mean_return = evaluate_model(
        model, eval_env, n_episodes=EVAL_EPISODES, max_ep_len=EVAL_EP_LEN, deterministic=DETERMINISTIC_EVAL
    )
    print("Episode returns:", [round(r, 3) for r in ep_returns])
    print("Mean return:", round(mean_return, 3))

    # Clean up eval env
    eval_env.close()

    # ----------------------------
    # 3) (Optional) EXTRA TEST RUN WITH DIFFERENT TAG/HEADLESS
    # ----------------------------
    # If you want a quick visual rollout after eval (e.g., GUI on), toggle HEADLESS_EVAL above
    # or create another env here with headless=False.

if __name__ == "__main__":
    main()
