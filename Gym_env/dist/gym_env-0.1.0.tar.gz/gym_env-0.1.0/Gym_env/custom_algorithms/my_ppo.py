import gymnasium as gym
import numpy as np
import torch
import torch.nn as nn
import torch.optim as optim
from torch.distributions import MultivariateNormal

class ActorCritic(nn.Module):
    def __init__(self, obs_dim, act_dim, hidden_size=64):
        super(ActorCritic, self).__init__()
        self.shared = nn.Sequential(
            nn.Linear(obs_dim, hidden_size),
            nn.Tanh(),
            nn.Linear(hidden_size, hidden_size),
            nn.Tanh()
        )
        self.actor_mean = nn.Linear(hidden_size, act_dim)
        self.actor_logstd = nn.Parameter(torch.zeros(act_dim))  # Learnable log std
        self.critic = nn.Linear(hidden_size, 1)

    def forward(self, x):
        features = self.shared(x)
        mean = self.actor_mean(features)
        value = self.critic(features)
        return mean, value

    def act(self, state, act_low, act_high, deterministic=False):
        # Expect state to be (obs_dim,), e.g., (11,) for AUV env
        state = np.array(state, dtype=np.float32)
        if state.shape != (self.shared[0].in_features,):
            raise ValueError(f"Expected state shape {(self.shared[0].in_features,)}, got {state.shape}")
        state = torch.FloatTensor(state).unsqueeze(0)
        mean, _ = self.forward(state)
        std = self.actor_logstd.exp()
        cov = torch.diag(std)
        dist = MultivariateNormal(mean, cov)
        if deterministic:
            action = mean
        else:
            action = dist.sample()
        action = torch.clamp(action, torch.FloatTensor(act_low), torch.FloatTensor(act_high))
        action_logprob = dist.log_prob(action)
        return action.squeeze(0).numpy(), action_logprob.squeeze(0).item()

    def evaluate(self, state, action):
        mean, value = self.forward(state)
        std = self.actor_logstd.exp()
        cov = torch.diag_embed(std.unsqueeze(0).repeat(state.shape[0], 1))
        dist = MultivariateNormal(mean, cov)
        action_logprobs = dist.log_prob(action)
        dist_entropy = dist.entropy()
        return action_logprobs, value.squeeze(-1), dist_entropy

class PPO:
    def __init__(self, env, lr=3e-4, gamma=0.99, clip_ratio=0.2, value_coef=0.5, entropy_coef=0.01,
                 max_grad_norm=0.5, target_kl=0.01, gae_lambda=0.95, batch_size=64, epochs=10,
                 hidden_size=64):
        self.env = env
        self.obs_dim = env.observation_space.shape[0]  # Should be 11 or 4
        self.act_dim = env.action_space.shape[0]
        self.act_low = env.action_space.low
        self.act_high = env.action_space.high
        self.policy = ActorCritic(self.obs_dim, self.act_dim, hidden_size)
        self.optimizer = optim.Adam(self.policy.parameters(), lr=lr)
        self.gamma = gamma
        self.clip_ratio = clip_ratio
        self.value_coef = value_coef
        self.entropy_coef = entropy_coef
        self.max_grad_norm = max_grad_norm
        self.target_kl = target_kl
        self.gae_lambda = gae_lambda
        self.batch_size = batch_size
        self.epochs = epochs

    def compute_advantages(self, rewards, values, dones):
        if len(rewards) != len(values) or len(rewards) != len(dones):
            raise ValueError(f"Length mismatch: rewards={len(rewards)}, values={len(values)}, dones={len(dones)}")
        advantages = np.zeros_like(rewards)
        last_gae = 0
        for t in reversed(range(len(rewards))):
            if t == len(rewards) - 1:
                next_value = 0 if dones[t] else values[t]
            else:
                next_value = values[t + 1]
            delta = rewards[t] + self.gamma * next_value * (1 - dones[t]) - values[t]
            advantages[t] = last_gae = delta + self.gamma * self.gae_lambda * (1 - dones[t]) * last_gae
        returns = advantages + values
        return advantages, returns

    def update(self, rollout):
        states = torch.FloatTensor(np.array(rollout['states']))
        actions = torch.FloatTensor(np.array(rollout['actions']))
        old_logprobs = torch.FloatTensor(np.array(rollout['logprobs']))
        advantages = torch.FloatTensor(rollout['advantages'])
        returns = torch.FloatTensor(rollout['returns'])

        advantages = (advantages - advantages.mean()) / (advantages.std() + 1e-8)

        for _ in range(self.epochs):
            for idx in range(0, len(states), self.batch_size):
                batch_states = states[idx:idx + self.batch_size]
                batch_actions = actions[idx:idx + self.batch_size]
                batch_old_logprobs = old_logprobs[idx:idx + self.batch_size]
                batch_advantages = advantages[idx:idx + self.batch_size]
                batch_returns = returns[idx:idx + self.batch_size]

                new_logprobs, values, entropy = self.policy.evaluate(batch_states, batch_actions)

                ratios = torch.exp(new_logprobs - batch_old_logprobs)
                surr1 = ratios * batch_advantages
                surr2 = torch.clamp(ratios, 1 - self.clip_ratio, 1 + self.clip_ratio) * batch_advantages
                actor_loss = -torch.min(surr1, surr2).mean()
                critic_loss = nn.MSELoss()(values, batch_returns)
                entropy_loss = entropy.mean()

                loss = actor_loss + self.value_coef * critic_loss - self.entropy_coef * entropy_loss

                self.optimizer.zero_grad()
                loss.backward()
                nn.utils.clip_grad_norm_(self.policy.parameters(), self.max_grad_norm)
                self.optimizer.step()

    def train(self, num_steps=1000000, rollout_steps=256):
        state, info = self.env.reset()
        rollout = {'states': [], 'actions': [], 'logprobs': [], 'rewards': [], 'dones': [], 'values': []}
        total_steps = 0
        episode_rewards = []
        episode_count = 0

        while total_steps < num_steps:
            episode_reward = 0
            for _ in range(rollout_steps):
                with torch.no_grad():
                    action, logprob = self.policy.act(state, self.act_low, self.act_high)
                    value = self.policy.forward(torch.FloatTensor(state).unsqueeze(0))[1].item()

                next_state, reward, terminated, truncated, info = self.env.step(action)
                done = terminated or truncated

                # print(f"Step {total_steps + 1}: reward={reward}, terminated={terminated}, truncated={truncated}, info={info}")
                episode_reward += reward

                rollout['states'].append(state)
                rollout['actions'].append(action)
                rollout['logprobs'].append(logprob)
                rollout['rewards'].append(reward)
                rollout['dones'].append(done)
                rollout['values'].append(value)

                state = next_state
                total_steps += 1

                if done:
                    episode_count += 1
                    print(f"Episode {episode_count} ended after {len(rollout['rewards'])} steps, reward={episode_reward}")
                    episode_rewards.append(episode_reward)

                    if len(rollout['rewards']) > 0:
                        with torch.no_grad():
                            last_value = self.policy.forward(torch.FloatTensor(state).unsqueeze(0))[1].item()
                        rollout['values'].append(last_value)
                        advantages, returns = self.compute_advantages(
                            rollout['rewards'], rollout['values'][:-1], rollout['dones']
                        )
                        rollout['advantages'] = advantages
                        rollout['returns'] = returns
                        self.update(rollout)

                    rollout = {'states': [], 'actions': [], 'logprobs': [], 'rewards': [], 'dones': [], 'values': []}
                    state, info = self.env.reset()
                    break  # Start new episode

            if len(rollout['rewards']) > 0 and not done:
                with torch.no_grad():
                    last_value = self.policy.forward(torch.FloatTensor(state).unsqueeze(0))[1].item()
                rollout['values'].append(last_value)
                advantages, returns = self.compute_advantages(
                    rollout['rewards'], rollout['values'][:-1], rollout['dones']
                )
                rollout['advantages'] = advantages
                rollout['returns'] = returns
                self.update(rollout)
                rollout = {'states': [], 'actions': [], 'logprobs': [], 'rewards': [], 'dones': [], 'values': []}

            if episode_rewards:
                print(f"Average episode reward (over {len(episode_rewards)} episodes): {np.mean(episode_rewards):.2f}")

# Usage example:
# env = gym.make('YourAUVEnv-v0')
# ppo = PPO(env)
# ppo.train()