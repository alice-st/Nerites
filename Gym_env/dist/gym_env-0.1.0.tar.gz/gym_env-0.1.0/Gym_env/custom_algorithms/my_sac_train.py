#!/usr/bin/env python3
import os
import sys
from pathlib import Path
import time
import numpy as np
import torch
import torch.nn as nn
import gymnasium as gym

# --- project root on sys.path ---
ROOT = Path(__file__).resolve().parents[1]  # …/Gym_env
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

# Ensure envs package is importable (registers your env)
import envs  # noqa: F401

# --- your algorithms ---
from my_sac import SAC   # Import SAC class from my_sac.py
from my_ppo import PPO   # Import PPO class from my_ppo.py
from my_ddpg_with_OU import DDPG # Import DDPG class from my_ddpg.py

# --- normalization wrapper (VecNormalize-like) ---
from normalize_env import NormalizeEnv

ENV_ID = "Nerites_mission_planning-v1"
TRAIN_ENV_NAME = "training_env1"
EVAL_ENV_NAME = "evaluation_env1"
MODEL_PATH = "auv_sac_model.pth"
NORM_STATS_PATH = "norm_stats_train.npz"

if __name__ == "__main__":
    # =========================
    # 1) TRAINING ENV (wrapped)
    # =========================
    env = gym.make(ENV_ID, env_id=TRAIN_ENV_NAME, headless=False, render_mode=None)
    # Z-score normalize observations + scale rewards by running return std
    env = NormalizeEnv(env, reward_norm="none", obs_clip=10.0, rew_clip=100.0, gamma=0.99, train=True)

    # Debug prints
    print("Raw observation space:", env.observation_space)
    print("Action space:", env.action_space)
    obs, info = env.reset()
    print("Sample normalized obs shape:", np.array(obs).shape)

    # # ----------------SAC----------------#
    # agent = SAC(
    #     env=env,
    #     buffer_size=1_000_000,  # Large buffer for diverse AUV experiences
    #     batch_size=256,         # Batch size for training
    #     gamma=0.99,             # Discount factor for long-horizon missions
    #     tau=0.005,              # Soft update rate
    #     alpha=0.2,              # Entropy regularization (tune for exploration)
    #     lr=3e-4                 # Learning rate
    # )

    # print("Starting training...")
    # agent.train(
    #     num_episodes=500,         # Number of episodes
    #     max_steps=2000,           # Max steps per episode
    #     save_path=MODEL_PATH      # Save in current directory
    # )

    # # Save normalization stats for evaluation
    # env.save_stats(NORM_STATS_PATH)
    # env.close()

    #----------------DDPG----------------#
    agent = DDPG(env=env, lr_actor=3e-4, lr_critic=3e-4, batch_size=256, noise_std=0.40, hidden_size=256,)
    agent.train(num_steps=500_000)
    env.save_stats(NORM_STATS_PATH)
    env.close()

    # =========================
    # 2) EVALUATION ENV (frozen)
    # =========================
    # Create a fresh env, wrap with NormalizeEnv(train=False) and load training stats
    eval_env = gym.make(ENV_ID, env_id=EVAL_ENV_NAME, headless=False, render_mode=None)
    eval_env = NormalizeEnv(eval_env, reward_norm="none", obs_clip=10.0, rew_clip=100.0, gamma=0.99, train=False)
    eval_env.load_stats(NORM_STATS_PATH)

    # Load the trained policy weights and evaluate
    print("\nStarting testing...")
    state = torch.load(MODEL_PATH)
    agent.actor.load_state_dict(state["actor"])
    agent.env = eval_env  # ensure the agent uses the eval env
    agent.test(
        num_episodes=10,   # Number of test episodes
        max_steps=2000     # Max steps per episode
    )
    eval_env.close()

    # ----------------PPO----------------#
    # If you want to try PPO instead, make sure to wrap envs the same way:
    # env = gym.make(ENV_ID, env_id=TRAIN_ENV_NAME, headless=True, render_mode=None)
    # env = NormalizeEnv(env, reward_norm="return", obs_clip=20.0, rew_clip=100.0, gamma=0.99, train=True)
    # agent = PPO(env=env)
    # agent.train(num_steps=500_000)
    # env.save_stats(NORM_STATS_PATH)
    # env.close()
    # eval_env = gym.make(ENV_ID, env_id=EVAL_ENV_NAME, headless=False, render_mode=None)
    # eval_env = NormalizeEnv(eval_env, reward_norm="return", obs_clip=20.0, rew_clip=100.0, gamma=0.99, train=False)
    # eval_env.load_stats(NORM_STATS_PATH)
    # agent.env = eval_env
    # agent.test(num_episodes=10, max_steps=2000)
    # eval_env.close()

