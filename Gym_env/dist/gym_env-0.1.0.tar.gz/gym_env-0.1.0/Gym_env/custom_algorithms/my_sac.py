import gymnasium as gym
import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.optim import Adam
from torch.distributions import Normal
import collections
import random
import pandas as pd
# Replay Buffer to store experiences for off-policy learning
class ReplayBuffer:
    def __init__(self, buffer_limit):
        self.buffer = collections.deque(maxlen=buffer_limit)

    def put(self, transition):
        self.buffer.append(transition)

    def sample(self, n):
        mini_batch = random.sample(self.buffer, n)
        s_lst, a_lst, r_lst, s_prime_lst, term_mask_lst, trunc_mask_lst = [], [], [], [], [], []

        for transition in mini_batch:
            s, a, r, s_prime, term_mask, trunc_mask = transition
            s_lst.append(np.array(s, dtype=np.float32).flatten())
            a_lst.append(np.array(a, dtype=np.float32).flatten())
            r_lst.append([r])
            s_prime_lst.append(np.array(s_prime, dtype=np.float32).flatten())
            term_mask_lst.append([term_mask])
            trunc_mask_lst.append([trunc_mask])

        s_array = np.stack(s_lst)
        a_array = np.stack(a_lst)
        r_array = np.array(r_lst, dtype=np.float32)
        s_prime_array = np.stack(s_prime_lst)
        term_mask_array = np.array(term_mask_lst, dtype=np.float32)
        trunc_mask_array = np.array(trunc_mask_lst, dtype=np.float32)

        return torch.tensor(s_array, dtype=torch.float), \
               torch.tensor(a_array, dtype=torch.float), \
               torch.tensor(r_array, dtype=torch.float), \
               torch.tensor(s_prime_array, dtype=torch.float), \
               torch.tensor(term_mask_array, dtype=torch.float), \
               torch.tensor(trunc_mask_array, dtype=torch.float)

    def size(self):
        return len(self.buffer)

# Actor network to output a stochastic policy (Gaussian distribution)
class Actor(nn.Module):
    def __init__(self, state_dim, action_dim, max_action):
        super(Actor, self).__init__()
        self.fc1 = nn.Linear(state_dim, 256)
        self.fc2 = nn.Linear(256, 256)
        self.mu = nn.Linear(256, action_dim)
        self.log_std = nn.Linear(256, action_dim)
        self.max_action = max_action
        self.LOG_STD_MIN = -20
        self.LOG_STD_MAX = 2

    def forward(self, state):
        x = F.relu(self.fc1(state))
        x = F.relu(self.fc2(x))
        mu = self.mu(x)
        log_std = self.log_std(x)
        log_std = torch.clamp(log_std, self.LOG_STD_MIN, self.LOG_STD_MAX)
        std = torch.exp(log_std)
        return mu, std

    def sample(self, state):
        mu, std = self.forward(state)
        normal = Normal(mu, std)
        z = normal.rsample()
        action = torch.tanh(z) * self.max_action
        log_prob = normal.log_prob(z) - torch.log(1 - action.pow(2) + 1e-6)
        log_prob = log_prob.sum(1, keepdim=True)
        return action, log_prob

# Critic network with two Q-value estimators to reduce overestimation bias
class Critic(nn.Module):
    def __init__(self, state_dim, action_dim):
        super(Critic, self).__init__()
        self.fc1 = nn.Linear(state_dim + action_dim, 256)
        self.fc2 = nn.Linear(256, 256)
        self.fc3 = nn.Linear(256, 1)
        self.fc4 = nn.Linear(state_dim + action_dim, 256)
        self.fc5 = nn.Linear(256, 256)
        self.fc6 = nn.Linear(256, 1)

    def forward(self, state, action):
        sa = torch.cat([state, action], 1)
        q1 = F.relu(self.fc1(sa))
        q1 = F.relu(self.fc2(q1))
        q1 = self.fc3(q1)
        q2 = F.relu(self.fc4(sa))
        q2 = F.relu(self.fc5(q2))
        q2 = self.fc6(q2)
        return q1, q2

    def Q1(self, state, action):
        sa = torch.cat([state, action], 1)
        q1 = F.relu(self.fc1(sa))
        q1 = F.relu(self.fc2(q1))
        q1 = self.fc3(q1)
        return q1

# SAC Agent
class SAC:
    def __init__(self, env, buffer_size=1000000, batch_size=256, gamma=0.99, tau=0.005, alpha=0.2, lr=0.0003):
        self.env = env
        self.state_dim = env.observation_space.shape[0]
        self.action_dim = env.action_space.shape[0]
        self.max_action = float(env.action_space.high[0])
        self.replay_buffer = ReplayBuffer(buffer_size)
        self.batch_size = batch_size
        self.gamma = gamma
        self.tau = tau
        self.alpha = alpha
        self.actor = Actor(self.state_dim, self.action_dim, self.max_action)
        self.critic = Critic(self.state_dim, self.action_dim)
        self.critic_target = Critic(self.state_dim, self.action_dim)
        self.critic_target.load_state_dict(self.critic.state_dict())
        self.actor_optimizer = Adam(self.actor.parameters(), lr=lr)
        self.critic_optimizer = Adam(self.critic.parameters(), lr=lr)
        self.episode_log = pd.DataFrame(columns=["episode", "steps", "reward", "avg_reward"])

    def select_action(self, state, evaluate=False):
        if isinstance(state, tuple):
            state = state[0]
        # print("State type:", type(state), "State shape:", np.shape(state))
        state = np.array(state, dtype=np.float32).flatten()
        if state.shape[0] != self.state_dim:
            raise ValueError(f"Expected state dimension {self.state_dim}, got {state.shape[0]}")
        state = torch.FloatTensor(state).unsqueeze(0)
        if evaluate:
            mu, _ = self.actor(state)
            action = torch.tanh(mu) * self.max_action
        else:
            action, _ = self.actor.sample(state)
        return action.detach().cpu().numpy()[0]

    def update(self):
        if self.replay_buffer.size() < self.batch_size:
            return
        state, action, reward, next_state, term_mask, trunc_mask = self.replay_buffer.sample(self.batch_size)
        with torch.no_grad():
            next_action, next_log_prob = self.actor.sample(next_state)
            q1_next_target, q2_next_target = self.critic_target(next_state, next_action)
            min_q_next_target = torch.min(q1_next_target, q2_next_target) - self.alpha * next_log_prob
            # Combine terminated and truncated for target Q calculation
            target_Q = reward + ((1 - term_mask) * (1 - trunc_mask) * self.gamma * min_q_next_target)
        q1, q2 = self.critic(state, action)
        critic_loss = F.mse_loss(q1, target_Q) + F.mse_loss(q2, target_Q)
        self.critic_optimizer.zero_grad()
        critic_loss.backward()
        self.critic_optimizer.step()
        pi, log_pi = self.actor.sample(state)
        q1_pi, q2_pi = self.critic(state, pi)
        min_Q = torch.min(q1_pi, q2_pi)
        actor_loss = (self.alpha * log_pi - min_Q).mean()
        self.actor_optimizer.zero_grad()
        actor_loss.backward()
        self.actor_optimizer.step()
        for param, target_param in zip(self.critic.parameters(), self.critic_target.parameters()):
            target_param.data.copy_(self.tau * param.data + (1 - self.tau) * target_param.data)

    def train(self, num_episodes=1000, max_steps=1000, save_path="sac_model.pth"):
        episode_rewards = []
        for episode in range(num_episodes):
            state = self.env.reset()
            if isinstance(state, tuple):
                state = state[0]
            episode_reward = 0
            for step in range(max_steps):
                action = self.select_action(state)
                next_state, reward, terminated, truncated, info = self.env.step(action)
                if isinstance(next_state, tuple):
                    next_state = next_state[0]
                term_mask = 1.0 if terminated else 0.0
                trunc_mask = 1.0 if truncated else 0.0
                self.replay_buffer.put((state, action, reward, next_state, term_mask, trunc_mask))
                self.update()
                state = next_state
                episode_reward += reward
                if terminated or truncated:
                    episode_rewards.append(episode_reward)
                    break
            print(f"Episode {episode}, Reward: {episode_reward:.2f}")

            self.episode_log.loc[len(self.episode_log)] = {
                "episode": episode,
                "steps": step,
                "reward": episode_reward,
                "avg_reward": np.mean(episode_rewards),
            }
            self.episode_log.to_csv(f"rewards/sac_rewards.csv", index=False)

            if episode % 100 == 0:
                torch.save({
                    'actor': self.actor.state_dict(),
                    'critic': self.critic.state_dict(),
                    'critic_target': self.critic_target.state_dict()
                }, save_path)

    def test(self, num_episodes=10, max_steps=1000):
        for episode in range(num_episodes):
            state = self.env.reset()
            if isinstance(state, tuple):
                state = state[0]
            episode_reward = 0
            for step in range(max_steps):
                action = self.select_action(state, evaluate=True)
                next_state, reward, terminated, truncated, info = self.env.step(action)
                if isinstance(next_state, tuple):
                    next_state = next_state[0]
                episode_reward += reward
                state = next_state
                if terminated or truncated:
                    break
            print(f"Test Episode {episode}, Reward: {episode_reward:.2f}")