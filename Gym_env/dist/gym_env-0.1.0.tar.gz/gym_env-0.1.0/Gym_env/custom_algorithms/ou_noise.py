import numpy as np

class OUNoise:
    def __init__(self, size, mu=0.0, theta=0.15, sigma=0.2, dt=0.02, x0=None, clip=None):
        self.size  = size
        self.mu    = np.full(size, mu, dtype=np.float32)
        self.theta = float(theta)
        self.sigma = float(sigma)   # you can change this on the fly (for decay)
        self.dt    = float(dt)
        self.x0    = None if x0 is None else np.array(x0, dtype=np.float32)
        self.clip  = clip
        self.reset()

    def reset(self):
        self.x_prev = np.zeros(self.size, dtype=np.float32) if self.x0 is None else self.x0.copy()

    def __call__(self):
        # x_t = x_{t-1} + theta*(mu - x_{t-1})*dt + sigma*sqrt(dt)*N(0,I)
        noise = np.random.normal(size=self.size).astype(np.float32)
        x = self.x_prev + self.theta * (self.mu - self.x_prev) * self.dt \
            + self.sigma * np.sqrt(self.dt) * noise
        if self.clip is not None:
            x = np.clip(x, -self.clip, self.clip)
        self.x_prev = x
        return x
