import gymnasium as gym
import numpy as np
import torch
import torch.nn as nn
import torch.optim as optim
import torch.nn.functional as F
from collections import deque
import random
import pandas as pd
import time

# ---------------- OU noise ----------------
class OUNoise:
    def __init__(self, size, mu=0.0, theta=0.15, sigma=0.2, dt=0.02, x0=None, clip=0.3):
        self.size  = int(size)
        self.mu    = float(mu)
        self.theta = float(theta)
        self.sigma = float(sigma)
        self.dt    = float(dt)
        self.x0    = np.zeros(self.size, dtype=np.float32) if x0 is None else np.array(x0, dtype=np.float32)
        self.clip  = float(clip) if clip is not None else None
        self.reset()

    def reset(self):
        self.x_prev = self.x0.copy()

    def __call__(self):
        # x_t = x_{t-1} + theta*(mu - x_{t-1})*dt + sigma*sqrt(dt)*N(0, I)
        n = np.random.normal(size=self.size).astype(np.float32)
        x = self.x_prev + self.theta * (self.mu - self.x_prev) * self.dt + self.sigma * np.sqrt(self.dt) * n
        if self.clip is not None:
            x = np.clip(x, -self.clip, self.clip)
        self.x_prev = x
        return x.astype(np.float32)

# ---------------- Models ----------------
class Actor(nn.Module):
    def __init__(self, obs_dim, act_dim, hidden_size=256):
        super().__init__()
        self.fc1 = nn.Linear(obs_dim, hidden_size)
        self.fc2 = nn.Linear(hidden_size, hidden_size)
        self.fc3 = nn.Linear(hidden_size, act_dim)

    def forward(self, state):
        # state: (B, obs_dim)
        x = F.relu(self.fc1(state))
        x = F.relu(self.fc2(x))
        return torch.tanh(self.fc3(x))  # actions in [-1, 1]


class Critic(nn.Module):
    def __init__(self, obs_dim, act_dim, hidden_size=256):
        super().__init__()
        self.fc1 = nn.Linear(obs_dim + act_dim, hidden_size)
        self.fc2 = nn.Linear(hidden_size, hidden_size)
        self.fc3 = nn.Linear(hidden_size, 1)

    def forward(self, state, action):
        # state: (B, obs_dim), action: (B, act_dim)
        x = torch.cat([state, action], dim=-1)
        x = F.relu(self.fc1(x))
        x = F.relu(self.fc2(x))
        return self.fc3(x)  # (B, 1)


# ---------------- Replay Buffer ----------------
class ReplayBuffer:
    def __init__(self, capacity=1_000_000):
        self.buffer = deque(maxlen=capacity)

    def push(self, state, action, reward, next_state, terminated, truncated):
        # Store terminated & truncated separately (only terminated stops bootstrapping)
        self.buffer.append((state, action, reward, next_state, terminated, truncated))

    def sample(self, batch_size):
        batch = random.sample(self.buffer, batch_size)
        states, actions, rewards, next_states, terms, truncs = zip(*batch)
        return (
            np.array(states, dtype=np.float32),
            np.array(actions, dtype=np.float32),
            np.array(rewards, dtype=np.float32),
            np.array(next_states, dtype=np.float32),
            np.array(terms, dtype=np.float32),
            np.array(truncs, dtype=np.float32),
        )

    def __len__(self):
        return len(self.buffer)


# ---------------- DDPG ----------------
class DDPG:
    def __init__(
        self, env,
        lr_actor=1e-4, lr_critic=1e-3, gamma=0.99, tau=0.005,
        buffer_size=1_000_000, batch_size=128, noise_std=0.2, hidden_size=256
    ):
        self.env = env
        self.device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

        self.obs_dim = int(env.observation_space.shape[0])
        self.act_dim = int(env.action_space.shape[0])
        self.act_high = np.asarray(env.action_space.high, dtype=np.float32)
        self.act_low  = np.asarray(env.action_space.low,  dtype=np.float32)
        self.act_mid  = (self.act_high + self.act_low) / 2.0
        self.act_rng  = (self.act_high - self.act_low) / 2.0  # map from [-1,1] to bounds

        # Networks
        self.actor = Actor(self.obs_dim, self.act_dim, hidden_size).to(self.device)
        self.actor_target = Actor(self.obs_dim, self.act_dim, hidden_size).to(self.device)
        self.actor_target.load_state_dict(self.actor.state_dict())
        self.actor_opt = optim.Adam(self.actor.parameters(), lr=lr_actor)

        self.critic = Critic(self.obs_dim, self.act_dim, hidden_size).to(self.device)
        self.critic_target = Critic(self.obs_dim, self.act_dim, hidden_size).to(self.device)
        self.critic_target.load_state_dict(self.critic.state_dict())
        self.critic_opt = optim.Adam(self.critic.parameters(), lr=lr_critic)

        self.gamma = float(gamma)
        self.tau = float(tau)
        self.batch_size = int(batch_size)

        self.replay_buffer = ReplayBuffer(buffer_size)

        # Logging
        self.episode_log = pd.DataFrame(columns=["episode", "steps", "reward", "avg_reward"])

        # ---------- OU noise (NEW) ----------
        dt = float(getattr(env, "control_period", 0.02))  # use your control timer if available
        self.ou = OUNoise(size=self.act_dim, theta=0.15, sigma=noise_std, dt=dt, clip=0.3)
        # Decay sigma over time
        self.sigma_start = float(noise_std)
        self.sigma_final = 0.05
        self.sigma_decay_steps = 100_000
        self.total_steps = 0  # updated during training

    # --------- Action selection ---------
    def act(self, state, noise=True):
        s = np.asarray(state, dtype=np.float32)
        if s.shape != (self.obs_dim,):
            raise ValueError(f"Expected state shape {(self.obs_dim,)}, got {s.shape}")

        with torch.no_grad():
            s_t = torch.from_numpy(s).unsqueeze(0).to(self.device)   # (1, obs_dim)
            a_tanh = self.actor(s_t).cpu().numpy().squeeze(0)        # in [-1,1]

        if noise:
            # Decay OU sigma
            frac = max(0.0, 1.0 - self.total_steps / self.sigma_decay_steps)
            self.ou.sigma = self.sigma_final + (self.sigma_start - self.sigma_final) * frac

            # Add OU noise in tanh space, then clip to [-1, 1]
            a_tanh = np.clip(a_tanh + self.ou(), -1.0, 1.0)

        # Map to env bounds and clip
        action = self.act_mid + self.act_rng * a_tanh
        action = np.clip(action, self.act_low, self.act_high).astype(np.float32)
        return action

    # --------- Training step ---------
    def update(self):
        if len(self.replay_buffer) < self.batch_size:
            return

        states, actions, rewards, next_states, terms, truncs = self.replay_buffer.sample(self.batch_size)

        # torch tensors
        states      = torch.from_numpy(states).to(self.device)                 # (B, obs)
        actions     = torch.from_numpy(actions).to(self.device)                # (B, act)
        rewards     = torch.from_numpy(rewards).unsqueeze(1).to(self.device)   # (B,1)
        next_states = torch.from_numpy(next_states).to(self.device)            # (B, obs)
        terminated  = torch.from_numpy(terms).unsqueeze(1).to(self.device)     # (B,1)
        # NOTE: truncated is logged but we keep bootstrapping through truncations
        not_terminated = 1.0 - terminated

        with torch.no_grad():
            next_actions = self.actor_target(next_states)
            target_q_next = self.critic_target(next_states, next_actions)      # (B,1)
            target_q = rewards + self.gamma * target_q_next * not_terminated   # Bellman target

        # Critic
        current_q = self.critic(states, actions)
        critic_loss = F.mse_loss(current_q, target_q)

        self.critic_opt.zero_grad(set_to_none=True)
        critic_loss.backward()
        self.critic_opt.step()

        # Actor (maximize Q)
        actor_actions = self.actor(states)
        actor_loss = -self.critic(states, actor_actions).mean()

        self.actor_opt.zero_grad(set_to_none=True)
        actor_loss.backward()
        self.actor_opt.step()

        # Soft update targets
        with torch.no_grad():
            for p, tp in zip(self.critic.parameters(), self.critic_target.parameters()):
                tp.data.mul_(1.0 - self.tau).add_(self.tau * p.data)
            for p, tp in zip(self.actor.parameters(), self.actor_target.parameters()):
                tp.data.mul_(1.0 - self.tau).add_(self.tau * p.data)

    # --------- Main training loop ---------
    def train(self, num_steps=1_000_000, update_freq=1, start_steps=5_000, log_csv="rewards/ddpg_rewards.csv"):
        state, info = self.env.reset()
        self.ou.reset()  # reset OU at episode start
        episode_reward = 0.0
        episode_steps = 0
        episode_rewards = []
        episode_count = 0

        while self.total_steps < num_steps:
            # Warmup with random actions in env bounds
            if self.total_steps < start_steps:
                action = self.env.action_space.sample().astype(np.float32)
                print("Exploring.....")
            else:
                action = self.act(state, noise=True)

            next_state, reward, terminated, truncated, info = self.env.step(action)
            done = bool(terminated or truncated)

            # Store transition
            self.replay_buffer.push(state, action, float(reward), next_state, float(terminated), float(truncated))
            print(float(reward))
            state = next_state
            episode_reward += float(reward)
            episode_steps  += 1
            self.total_steps += 1

            # Updates
            if self.total_steps >= start_steps and (self.total_steps % update_freq == 0):
                self.update()

            # Episode boundary
            if done:
                episode_count += 1
                avg = np.mean(episode_rewards + [episode_reward]) if episode_rewards else episode_reward
                print(f"Episode {episode_count} ended after {episode_steps} steps, reward={episode_reward}")
                print(f"Average episode reward (over {max(1,len(episode_rewards)+1)} episodes): {avg:.2f}")
                self.episode_log.loc[len(self.episode_log)] = {
                    "episode": episode_count,
                    "steps": episode_steps,
                    "reward": episode_reward,
                    "avg_reward": avg,
                }
                self.episode_log.to_csv(log_csv, index=False)

                # Reset episode + OU process
                episode_rewards.append(episode_reward)
                episode_reward = 0.0
                episode_steps = 0
                state, info = self.env.reset()
                self.ou.reset()
                print("============================================================================")
