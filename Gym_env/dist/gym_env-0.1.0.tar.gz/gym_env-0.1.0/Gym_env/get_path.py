import numpy as np
from utils import Pose, quaternion_to_yaw, wrap_to_pi

class PathParser(object):
    def __init__(self, start: Pose, distance: float, n: int, generate_random_path=True):
        self.generate_random_path = generate_random_path
        self.initial_auv_position = start
        self.distance = distance
        self.number_of_waypoints = n


    def get_path(self):
        if self.generate_random_path:
            goals = self._generate_random_goals()
            return goals

    def _generate_random_goals(self):
        goals: List[np.ndarray] = []
    
        for _ in range(self.number_of_waypoints):
            angle = np.random.uniform(0, 2 * np.pi)
            gx = self.initial_auv_position.x + self.distance * np.cos(angle)
            gy = self.initial_auv_position.y + self.distance * np.sin(angle)
            gz = self.initial_auv_position.z
            goals.append(np.array([gx, gy, gz], dtype=float))

        return goals