import torch
import torch.nn as nn
import torch.optim as optim
import gym
import envs
import numpy as np
import random
from collections import deque
import copy

# Hyperparameters
BUFFER_SIZE = int(1e6)
BATCH_SIZE = 128
GAMMA = 0.99
TAU = 0.005
ACTOR_LR = 1e-4
CRITIC_LR = 1e-3

device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

# Replay Buffer
class ReplayBuffer:
    def __init__(self, capacity):
        self.buffer = deque(maxlen=capacity)
    
    def push(self, *transition):
        self.buffer.append(transition)
    
    def sample(self, batch_size):
        transitions = random.sample(self.buffer, batch_size)
        return map(np.stack, zip(*transitions))
    
    def __len__(self):
        return len(self.buffer)

# Actor Network
class Actor(nn.Module):
    def __init__(self, state_dim, action_dim, max_action):
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(state_dim, 400), nn.ReLU(),
            nn.Linear(400, 300), nn.ReLU(),
            nn.Linear(300, action_dim), nn.Tanh()
        )
        self.max_action = max_action
    
    def forward(self, state):
        return self.max_action * self.net(state)

# Critic Network
class Critic(nn.Module):
    def __init__(self, state_dim, action_dim):
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(state_dim + action_dim, 400), nn.ReLU(),
            nn.Linear(400, 300), nn.ReLU(),
            nn.Linear(300, 1)
        )
    
    def forward(self, state, action):
        return self.net(torch.cat([state, action], dim=1))

# Ornstein-Uhlenbeck Noise
class OUNoise:
    def __init__(self, size, mu=0, theta=0.15, sigma=0.2):
        self.mu = mu
        self.theta = theta
        self.sigma = sigma
        self.state = np.ones(size) * mu
    
    def reset(self):
        self.state = np.ones_like(self.state) * self.mu
    
    def sample(self):
        dx = self.theta *(self.mu - self.state) + self.sigma * np.random.randn(len(self.state))
        self.state += dx
        return self.state

# Training function
def train():
    env = gym.make("Nerites_mission_planning-v0")
    state_dim = env.observation_space.shape[0]
    action_dim = env.action_space.shape[0]
    max_action = float(env.action_space.high[0])

    actor = Actor(state_dim, action_dim, max_action).to(device)
    actor_target = copy.deepcopy(actor)
    actor_optimizer = optim.Adam(actor.parameters(), lr=ACTOR_LR)

    critic = Critic(state_dim, action_dim).to(device)
    critic_target = copy.deepcopy(critic)
    critic_optimizer = optim.Adam(critic.parameters(), lr=CRITIC_LR)

    buffer = ReplayBuffer(BUFFER_SIZE)
    noise = OUNoise(action_dim)

    episodes = 100
    max_steps = 100
    for ep in range(episodes):
        state= env.reset()        
        noise.reset()
        episode_reward = 0
        steps=0

        for t in range(max_steps):
            python  = torch.FloatTensor(np.array(state)).unsqueeze(0).to(device)
            action = actor(python).cpu().data.numpy().flatten()
            action += noise.sample()
            action = np.clip(action, -max_action, max_action)

            next_state, reward, done, _ = env.step(action)
            buffer.push(state, action, reward, next_state, done)
            steps+=1
            state = next_state
            episode_reward += reward
            if len(buffer) > BATCH_SIZE:
                states, actions, rewards, next_states, dones = buffer.sample(BATCH_SIZE)
                states = torch.FloatTensor(states).to(device)
                actions = torch.FloatTensor(actions).to(device)
                rewards = torch.FloatTensor(rewards).unsqueeze(1).to(device)
                next_states = torch.FloatTensor(next_states).to(device)
                dones = torch.FloatTensor(dones).unsqueeze(1).to(device)

                with torch.no_grad():
                    target_actions = actor_target(next_states)
                    target_q = critic_target(next_states, target_actions)
                    y = rewards + GAMMA * (1 - dones)  *target_q

                critic_loss = nn.MSELoss()(critic(states, actions), y)
                critic_optimizer.zero_grad()
                critic_loss.backward()
                critic_optimizer.step()

                actor_loss = -critic(states, actor(states)).mean()
                actor_optimizer.zero_grad()
                actor_loss.backward()
                actor_optimizer.step()

                for param, target_param in zip(critic.parameters(), critic_target.parameters()):
                    target_param.data.copy_(TAU *param.data + (1 - TAU) * target_param.data)
                for param, target_param in zip(actor.parameters(), actor_target.parameters()):
                    target_param.data.copy_(TAU  *param.data + (1 - TAU) * target_param.data)

            if done:
                print("DONE!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!")
                break

        print(f"Episode {ep}, Reward: {episode_reward:.2f}, Steps: {steps}")

    env.close()

if __name__ == "__main__":
    train()