import torch
# import gym
import gymnasium as gym  # New standard after Gym v21.0
import envs
import numpy as np
import time
from stable_baselines3 import DDPG,PPO
from stable_baselines3.common.noise import NormalActionNoise, OrnsteinUhlenbeckActionNoise
from stable_baselines3.common.env_checker import check_env
import os

env = gym.make("Nerites_mission_planning-v0",headless=True)
check_env(env, warn=True)
time.sleep(5.0)

# Action noise for exploration
n_actions = env.action_space.shape[-1]
action_noise = OrnsteinUhlenbeckActionNoise(
    mean=np.zeros(n_actions), 
    sigma=0.1 * np.ones(n_actions),
    theta=0.15,
    dt=1e-2
)

model = DDPG(
    "MlpPolicy",
    env,
    learning_rate=1e-4,
    buffer_size=1000000,
    learning_starts=10000,
    batch_size=256,
    tau=0.005,
    gamma=0.99,
    train_freq=1,
    gradient_steps=1,
    action_noise=action_noise,
    replay_buffer_class=None,
    replay_buffer_kwargs=None,
    optimize_memory_usage=False,
    policy_kwargs=dict(net_arch=[400, 300]),
    tensorboard_log=None,
    verbose=1,
    device="auto",
    seed=None,
)

# model = PPO(
#     "MlpPolicy",
#     env,
#     verbose=1,
# )

model.learn(total_timesteps=50000, log_interval=10)
model.save("ddpg2")
# vec_env = model.get_env()

# del model # remove to demonstrate saving and loading

# model = DDPG.load("ddpg")


for episode in range(10):
    print(f"\n--- Episode {episode + 1} ---")
    obs,info = env.reset()
    # time.sleep(5.0)
    for t in range(302):
        action, _states = model.predict(obs)
        obs, rewards, terminated, truncated, info = env.step(action)
        if terminated or truncated:   
            # print(terminated)
            # print(obs)
            # print(rewards)
            break
env.close()
