import torch
import torch.nn as nn
import os
import time
import gymnasium as gym
import numpy as np
from gymnasium.vector import AsyncVectorEnv

# --- Stable-Baselines3 Imports ---
from stable_baselines3 import SAC
from stable_baselines3.common.env_util import make_vec_env
from stable_baselines3.common.vec_env import VecNormalize
from stable_baselines3.common.vec_env import SubprocVecEnv,DummyVecEnv
from stable_baselines3.common.monitor import Monitor
from stable_baselines3.common.callbacks import EvalCallback
from stable_baselines3.common.env_checker import check_env
import envs
from typing import Callable, List, Optional, Any, Sequence, Tuple, Union
import numpy as np
from gymnasium import Env
from gymnasium.vector import AsyncVectorEnv
from stable_baselines3.common.vec_env import VecEnv
import datetime


def make_env_fn(rank: int):
    def _init():
        return gym.make(
            ENV_ID,
            env_id=f"training_env{rank}",
            headless=True,
            render_mode=None,
        )
    return _init


if __name__ == '__main__':
    ENV_ID = "Nerites_mission_planning-v1"
    NUM_PARALLEL_ENVS = 1 # Number of environments to run in parallel
    LOG_DIR = "Training_data/sac_logs"
    BEST_MODEL_SAVE_PATH = os.path.join(LOG_DIR, "0.5_meters")
    MODEL_PATH = os.path.join(BEST_MODEL_SAVE_PATH, "best_model2.zip")
    
    os.makedirs(LOG_DIR, exist_ok=True)
    os.makedirs(BEST_MODEL_SAVE_PATH, exist_ok=True)

    print(f"Creating {NUM_PARALLEL_ENVS} parallel environments for training...")
    # def make_env():
    #     return gym.make(ENV_ID, headless=True, render_mode=None)
        
    # train_env = gym.make(ENV_ID, headless=True, render_mode=None)
    train_env = DummyVecEnv([make_env_fn(i) for i in range(NUM_PARALLEL_ENVS)])

    # train_env = make_vec_env(ENV_ID, n_envs=NUM_PARALLEL_ENVS, env_kwargs={"headless": True,"render_mode": None})
    train_env = VecNormalize(train_env, norm_obs=True, norm_reward=True) # Normalize it

    print("Creating a separate environment for evaluation...")
    # eval_env = gym.make(ENV_ID, headless=True, render_mode=None)
    eval_env = make_vec_env(ENV_ID, n_envs=1, env_kwargs={"env_id": "evaluation_env_999", "headless": True,"render_mode": None})
    eval_env = VecNormalize(eval_env, norm_obs=True, norm_reward=False) # Normalize it
    # check_env(eval_env) # This will raise errors if something is wrong
    # eval_env = Monitor(eval_env)
    time.sleep(5.0) 

    eval_callback = EvalCallback(eval_env,
                                 best_model_save_path=BEST_MODEL_SAVE_PATH,
                                 log_path=LOG_DIR,
                                 n_eval_episodes= 10,
                                 eval_freq=10000// NUM_PARALLEL_ENVS,  # Adjusted for parallel environments
                                 deterministic=True,
                                 render=False)

    # Custom policy network architecture (unchanged)
    policy_kwargs = dict(
        net_arch=dict(pi=[256, 256], qf=[256, 256]),
        activation_fn=nn.ReLU,
    )

    def linear_schedule(initial_value: float) -> Callable[[float], float]:
        """
        Linear learning rate schedule.
        :param initial_value: Initial learning rate.
        :return: schedule that computes current learning rate depending on
        progress remaining (from 1 to 0).
        """
        def func(progress_remaining: float) -> float:
            """
            Progress will decrease from 1 (beginning) to 0 (end).
            """
            return progress_remaining * initial_value
        return func
    # --- 4. Load Existing Model or Create New One ---
    
   # --- NEW, CORRECT CODE (SIMPLE) ---
    if os.path.exists(MODEL_PATH):
        print(f"--- Loading existing model from {MODEL_PATH} ---")
        model = SAC.load(MODEL_PATH, env=train_env)

        # Tell the loaded model where to log for the *next* training session.
        # The .learn() method will use this path to set up the logger.
        model.tensorboard_log = LOG_DIR

    else:
        print("--- No existing model found, creating a new one ---")
        model = SAC(
            "MlpPolicy",
            train_env, 
            learning_rate=linear_schedule(3e-4),
            buffer_size=1000000,
            learning_starts=1000,
            batch_size=256, 
            tau=0.01,
            gamma=0.99,
            train_freq=(1, 'step'), 
            gradient_steps=1,
            ent_coef='auto',
            policy_kwargs=policy_kwargs,
            verbose=1,
            tensorboard_log=LOG_DIR,
        )
        

    print("Starting training...")
    start_time = time.time()
    
    try:
        model.learn(total_timesteps=500000,
                    callback=eval_callback,
                    log_interval=20,
                    tb_log_name= 'SAC'+ datetime.datetime.now().strftime("%Y%m%d-%H%M%S"),
                    reset_num_timesteps=False, # Set to False to continue from loaded model's steps
                    progress_bar=True)
    finally:
            print("Training stopped. Calling env.close() to clean up...")
            model.save(os.path.join(LOG_DIR, "sac_final_model2.zip"+ datetime.datetime.now().strftime("%Y%m%d-%H%M%S")))
            train_env.close()
            eval_env.close()
    
    # Save the final model
    model.save(os.path.join(LOG_DIR, "sac_final_model2.zip"))
    end_time = time.time()
    print(f"Training finished in {(end_time - start_time) / 60:.2f} minutes.")


    # --- 6. Evaluate the Final Agent ---

    test_env = gym.make(ENV_ID, headless=False, render_mode=None)


    print("\n--- Evaluating the final agent ---")
    for episode in range(10):
        print(f"\n--- Episode {episode + 1} ---")
        # Use the single eval_env for testing
        obs, info = test_env.reset()
        
        for t in range(750):
            # Use deterministic=True for the best action during evaluation
            action, _states = model.predict(obs, deterministic=True)
            obs, reward, terminated, truncated, info = test_env.step(action)
            
            if t == 749:
                print(obs)
            if terminated or truncated:
                print(f"Episode finished after {t+1} timesteps.")
                print(f"Terminated: {terminated}, Truncated: {truncated}")
                print(f"Final Observation:\n{obs}")
                print(f"Final Reward: {reward}")
                break
                
    # train_env.close()
    # eval_env.close()
    # test_env.close()