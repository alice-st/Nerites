import os, time, signal, subprocess, atexit

class SimLauncher:
    def __init__(self, world_launch:str, model_launch:str, ns:str,
                 entity_name:str=None, headless:bool=True,
                 ros_domain_id:int=51, gazebo_port:int=11346):
        
        self.world_launch = world_launch
        self.model_launch = model_launch
        self.ns = ns
        self.entity_name = entity_name or f"{ns}_entity"
        self.headless = bool(headless)
        self.ros_domain_id = int(ros_domain_id)
        self.gazebo_port = int(gazebo_port)
        self.envp = os.environ.copy()
        self.envp["ROS_DOMAIN_ID"] = str(self.ros_domain_id)
        self.envp["GAZEBO_MASTER_URI"] = f"http://127.0.0.1:{self.gazebo_port}"
        self._procs = []

    def start(self, settle_world:float=8.0):
        gui_arg = "false" if self.headless else "true"
        gui_arg = "true"
        uri = self.envp["GAZEBO_MASTER_URI"]
        rdomain = self.envp["ROS_DOMAIN_ID"]
        # 1) Gazebo world
        self.gazebo_process = subprocess.Popen(
            [
                "ros2", "launch", self.world_launch,
                f"gui:={gui_arg}",
                f"gazebo_master_uri:={uri}",   
                f"ros_domain_id:={rdomain}",     
            ],
            env=self.envp, preexec_fn=os.setsid,
            stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL
        )
        time.sleep(settle_world)

        # 2) Robot model
        self.robot_model_process = subprocess.Popen(
        ["ros2", "launch", self.model_launch,
        f"namespace:={self.ns}",
        f"entity_name:={self.entity_name}"],
        env=self.envp, preexec_fn=os.setsid, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL
        )

        # small settle
        time.sleep(2.0)

    def stop(self):
        for p in self._procs:
            if p and p.poll() is None:
                try:
                    os.killpg(os.getpgid(p.pid), signal.SIGTERM)
                    p.wait(timeout=5)
                except Exception:
                    try:
                        os.killpg(os.getpgid(p.pid), signal.SIGKILL)
                    except Exception:
                        pass
        self._procs.clear()
