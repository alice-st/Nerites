#!/usr/bin/env python3
from __future__ import annotations
import os, sys, time, uuid, atexit, signal, subprocess, math, re
from typing import Optional, List
import numpy as np

import rclpy
from rclpy.node import Node
from rclpy.parameter import Parameter
from rclpy.time import Time as RclpyTime

from nav_msgs.msg import Odometry
from std_srvs.srv import Empty
from gazebo_msgs.srv import SpawnEntity, DeleteEntity
from uuv_gazebo_ros_plugins_msgs.msg import FloatStamped
import os
print("Current working directory:", os.getcwd())
from Gym_env.local_planner.waypoint_generator import WaypointHandler

# ---- your helpers (unchanged) ----
from utils import Velocity, Pose, str2bool, quat_to_rpy, load_settings_txt, _make_env_tag, _derive_env_offset

CONFIG_PATH = "~/ros2_ws/src/Gym_env/settings.txt"

def wrap_to_pi(a):
    return (a + math.pi) % (2*math.pi) - math.pi

class YawPID:
    def __init__(self, Kp=200.0, Ki=15.0, Kd=35.0, u_max=400.0, tau_d=0.05):
        self.Kp, self.Ki, self.Kd = float(Kp), float(Ki), float(Kd)
        self.u_max = float(u_max)
        self.tau_d = float(tau_d)
        self.reset()

    def reset(self):
        self.I = 0.0
        self.e_prev = 0.0
        self.d_prev = 0.0
        self.yaw_ref_prev = None

    @staticmethod
    def ang_diff(a, b):
        return wrap_to_pi(a - b)

    def step(self, yaw_ref, yaw, dt, yaw_rate=None):
        e = self.ang_diff(yaw_ref, yaw)

        if self.yaw_ref_prev is None:
            dyaw_ref = 0.0
        else:
            dyaw_ref = self.ang_diff(yaw_ref, self.yaw_ref_prev) / max(dt, 1e-6)
        self.yaw_ref_prev = yaw_ref

        if yaw_rate is not None:
            d_raw = dyaw_ref - float(yaw_rate)
        else:
            d_raw = (e - self.e_prev) / max(dt, 1e-6)
        self.e_prev = e

        # low-pass derivative
        alpha = self.tau_d / (self.tau_d + max(dt, 1e-6))
        d = alpha * self.d_prev + (1.0 - alpha) * d_raw
        self.d_prev = d

        # PID + simple anti-windup
        u_p = self.Kp * e
        u_d = self.Kd * d
        self.I += self.Ki * e * dt
        u = u_p + self.I + u_d

        if u > self.u_max:
            if e > 0:
                self.I -= self.Ki * e * dt
            u = self.u_max
        elif u < -self.u_max:
            if e < 0:
                self.I -= self.Ki * e * dt
            u = -self.u_max

        return float(u)

class StandaloneAUV(Node):
    """
    Standalone ROS2 node: launches Gazebo + model, reads odom, runs PID on yaw, publishes thrusters.
    No Gym. No complementary env class.
    """
    def __init__(self,
                 env_id: Optional[str] = "pid_env1",
                 env_offset: Optional[str] = "pid_env1",
                 config_path: Optional[str] = None,
                 headless: Optional[bool] = None,
                 uuv_name: Optional[str] = None,
                 control_period: float = 0.1,
                 yaw_ref_deg: float = 0.0,
                 pid_gains=(200.0, 15.0, 35.0),
                 u_max: float = 400.0,
                 ):

        env_id = env_id if env_id is not None else 0
        cfg = load_settings_txt(config_path or CONFIG_PATH)

        if headless is not None:  cfg["headless"] = headless
        if uuv_name is not None:  cfg["uuv_name"] = uuv_name

        self.headless = str2bool(cfg["headless"])
        self.uuv_name = str(cfg["uuv_name"])
        self.num_thrusters = int(cfg["num_thrusters"])

        # names/launch files
        self.WORLD_LAUNCH = cfg["WORLD_LAUNCH"]
        self.MODEL_LAUNCH = cfg["MODEL_LAUNCH"]
        self.POSE_TOPIC = None   # filled after ns build
        self.THRUSTER_TOPIC_FMT = None

        # per-env namespace
        self.env_tag = _make_env_tag(env_id)
        self.namespace_token = f"{self.env_tag}_{self.uuv_name}".replace("/", "_")
        san_env = re.sub(r'[^A-Za-z0-9_]+', '_', self.env_tag)
        self.entity_name = f"{self.uuv_name}_{san_env}"

        super().__init__(f"auv_pid_{env_offset}_{uuid.uuid4().hex[:6]}")
        self.set_parameters([Parameter('use_sim_time', Parameter.Type.BOOL, True)])

        atexit.register(self._hard_close)

        # topics with namespace
        self.POSE_TOPIC = self.namespace_token + cfg["POSE_TOPIC"]
        self.THRUSTER_TOPIC_FMT = self.namespace_token + cfg["THRUSTER_TOPIC_FMT"]

        # services
        self.reset_sim_client   = self.create_client(Empty, '/gazebo/reset_world')
        self.unpause_sim_client = self.create_client(Empty, '/gazebo/unpause_physics')
        self.spawn_entity_client  = self.create_client(SpawnEntity, '/gazebo/spawn_entity')
        self.delete_entity_client = self.create_client(DeleteEntity, '/gazebo/delete_entity')

        # state
        self.control_period = float(control_period)
        self.yaw_ref = math.radians(float(yaw_ref_deg))
        self.odom_pose: Pose | None = None
        self.current_speed: Velocity | None = None
        self._pose_seq = 0

        # PID
        Kp, Ki, Kd = pid_gains
        self.pid = YawPID(Kp=Kp, Ki=Ki, Kd=Kd, u_max=float(u_max), tau_d=0.05)

        # bring-up
        self._launch_simulation()
        self.get_logger().info(
            f"env_tag={self.env_tag} domain={os.environ['ROS_DOMAIN_ID']} uri={os.environ['GAZEBO_MASTER_URI']}"
        )

        # pubs/subs
        self.thruster_pubs = [
            self.create_publisher(FloatStamped, self.THRUSTER_TOPIC_FMT.format(i), 10)
            for i in range(self.num_thrusters)
        ]
        self.pose_subscription = self.create_subscription(
            Odometry, self.POSE_TOPIC, self._pose_cb, 10)

        # wait until first odom arrives
        self._wait_for_initial_state()
        self.get_logger().info("PID initialized.")

        self.goals = self.build_goals()
        # control timer
        self.timer = self.create_timer(self.control_period, self._control_step)

    # ---------- Gazebo bring-up ----------
    def _launch_simulation(self):
        envp = os.environ.copy()
        master_uri = envp["GAZEBO_MASTER_URI"]
        ros_domain = envp["ROS_DOMAIN_ID"]
        time.sleep(2)
        gui_arg = "false" if self.headless else "true"
        self.get_logger().info(f"Launching Gazebo gui:={gui_arg}")

        self.gazebo_process = subprocess.Popen(
            ["ros2", "launch", self.WORLD_LAUNCH,
             f"gui:={gui_arg}",
             f"gazebo_master_uri:={master_uri}",
             f"ros_domain_id:={ros_domain}"],
            env=envp, preexec_fn=os.setsid,
            stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL
        )

        time.sleep(6)
        self.robot_model_process = subprocess.Popen(
            ["ros2", "launch", self.MODEL_LAUNCH,
             f"namespace:={self.namespace_token}",
             f"entity_name:={self.entity_name}"],
            env=envp, preexec_fn=os.setsid,
            stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL
        )

    def _wait_for_initial_state(self):
        self.get_logger().info(f"Waiting for initial pose on {self.POSE_TOPIC}…")
        t0 = time.time()
        while rclpy.ok() and self.odom_pose is None and (time.time() - t0) < 30.0:
            rclpy.spin_once(self, timeout_sec=0.1)
        if self.odom_pose is None:
            self.get_logger().error("Never received initial pose. Exiting.")
            self._hard_close()
            sys.exit(1)
        self.get_logger().info("Initial pose received.")

    # ---------- ROS callbacks ----------
    def _pose_cb(self, msg: Odometry)-> None:
        q = msg.pose.pose.orientation
        roll, pitch, yaw = quat_to_rpy(q.x, q.y, q.z, q.w)
        self.odom_pose = Pose(
            msg.pose.pose.position.x,
            msg.pose.pose.position.y,
            msg.pose.pose.position.z,
            roll, pitch, yaw
        )
        self.current_speed = Velocity(msg.twist.twist.linear, msg.twist.twist.angular)
        self._pose_seq += 1

    # -------- Build goal positions --------
    def build_goals(self) -> List[Pose]:
        # Build once; keep handler around for obs/reward
        self.waypoint_handler = WaypointHandler(self.node, self.env_id)
        start = Pose(0.0, 0.0, -20.0, 0.0, 0.0, 0.0)
        self.waypoint_handler.build_random(start, n=self.number_of_target_waypoints)
        pnts = self.waypoint_handler.goal_waypoints  # [(x,y,z,s), ...]
        self.waypoint_handler.build_catmull_rom_coeffs(closed=False)

        goals: List[Pose] = []
        for i, (x, y, z, _) in enumerate(pnts):
            yaw = 0.0
            if i < len(pnts) - 1:
                nx, ny, nz, _ = pnts[i+1]
                yaw = math.atan2(ny - y, nx - x)
            goals.append(Pose(x, y, z, 0.0, 0.0, yaw))
        
        return goals

    # ---------- Control ----------
    def _control_step(self):
        # wait until we have pose
        if self.odom_pose is None or self.current_speed is None:
            return

        dt = self.control_period
        yaw      = float(self.odom_pose.yaw)
        yaw_rate = float(self.current_speed.angular_velocity[2])  # angular.z

        # PID
        u = self.pid.step(self.yaw_ref, yaw, dt, yaw_rate=yaw_rate)

        # Map to thrusters (pure yaw): left = +u, right = -u
        left, right = float(np.clip(u, -self.pid.u_max, self.pid.u_max)), \
                      float(np.clip(-u, -self.pid.u_max, self.pid.u_max))

        for i, pub in enumerate(self.thruster_pubs):
            msg = FloatStamped()
            msg.header.stamp = self.get_clock().now().to_msg()
            if i in (3, 8):        # left / port group
                msg.data = left
            elif i in (2, 7):      # right / starboard group
                msg.data = right
            else:
                msg.data = 0.0
            pub.publish(msg)

        # optional: log lightly
        self.get_logger().info(f"yaw_ref={self.yaw_ref:.2f} yaw={yaw:.2f} u={u:.1f}")

    # ---------- Shutdown ----------
    def _hard_close(self):
        # kill spawned processes
        for proc_attr in ("robot_model_process", "gazebo_process"):
            proc = getattr(self, proc_attr, None)
            if proc is not None and proc.poll() is None:
                try:
                    os.killpg(os.getpgid(proc.pid), signal.SIGTERM)
                    proc.wait(timeout=5)
                except Exception:
                    try:
                        os.killpg(os.getpgid(proc.pid), signal.SIGKILL)
                    except Exception:
                        pass
                finally:
                    setattr(self, proc_attr, None)

def main():
    env_id = "training_env1"
    env_offset = _derive_env_offset(env_id)
    os.environ["ROS_DOMAIN_ID"]     = str((50 + env_offset) % 232)
    os.environ["GAZEBO_MASTER_URI"] = f"http://127.0.0.1:{11345 + env_offset}"

    rclpy.init()

    node = StandaloneAUV(
        env_id=env_id,
        env_offset = env_offset,
        config_path=CONFIG_PATH,
        headless=True,
        uuv_name="x300",
        control_period=0.1,
        yaw_ref_deg=40.0,
        pid_gains=(200.0, 15.0, 35.0),
        u_max=400.0)
    try:
        rclpy.spin(node)
    finally:
        node._hard_close()
        node.destroy_node()
        rclpy.shutdown()

if __name__ == '__main__':
    main()
