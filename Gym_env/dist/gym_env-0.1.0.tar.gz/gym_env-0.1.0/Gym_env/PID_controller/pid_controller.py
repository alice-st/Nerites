#!/usr/bin/env python3
# yaw_pid_node.py (pure ROS2 PID controller for yaw)
import math
import argparse
from typing import List, Optional

import rclpy
from rclpy.node import Node
from nav_msgs.msg import Odometry
from std_msgs.msg import Float32
from uuv_gazebo_ros_plugins_msgs.msg import FloatStamped
from sim_launcher import SimLauncher
import os, time, signal, subprocess, atexit

# ----------------- math helpers -----------------
def wrap_pi(a: float) -> float:
    """Wrap angle to (-pi, pi]."""
    return (a + math.pi) % (2.0 * math.pi) - math.pi

def ang_diff(a: float, b: float) -> float:
    """Smallest signed difference a - b wrapped to (-pi, pi]."""
    return wrap_pi(a - b)

def quat_to_yaw(x: float, y: float, z: float, w: float) -> float:
    """Quaternion -> yaw (rad) assuming ROS ENU (roll X, pitch Y, yaw Z)."""
    # Normalize
    n = math.sqrt(x*x + y*y + z*z + w*w)
    if n == 0.0:
        return 0.0
    x, y, z, w = x/n, y/n, z/n, w/n
    # Yaw
    t3 = +2.0 * (w * z + x * y)
    t4 = +1.0 - 2.0 * (y * y + z * z)
    return math.atan2(t3, t4)

# ----------------- PID core -----------------
class YawPID:
    def __init__(self, kp=200.0, ki=15.0, kd=35.0, u_max=400.0, tau_d=0.05):
        self.Kp = float(kp)
        self.Ki = float(ki)
        self.Kd = float(kd)
        self.u_max = float(u_max)
        self.tau_d = float(tau_d)
        self.reset()

    def reset(self):
        self.I = 0.0
        self.e_prev = 0.0
        self.d_prev = 0.0
        self.yaw_ref_prev: Optional[float] = None

    def step(self, yaw_ref: float, yaw: float, dt: float, yaw_rate: Optional[float] = None) -> float:
        dt = max(float(dt), 1e-6)

        # error (wrapped)
        e = ang_diff(yaw_ref, yaw)

        # reference rate (if ref moves)
        if self.yaw_ref_prev is None:
            dyaw_ref = 0.0
        else:
            dyaw_ref = ang_diff(yaw_ref, self.yaw_ref_prev) / dt
        self.yaw_ref_prev = yaw_ref

        # derivative (prefer measured yaw_rate)
        if yaw_rate is not None:
            d_raw = dyaw_ref - float(yaw_rate)
        else:
            d_raw = (e - self.e_prev) / dt
        self.e_prev = e

        # low-pass derivative
        alpha = self.tau_d / (self.tau_d + dt)
        d = alpha * self.d_prev + (1.0 - alpha) * d_raw
        self.d_prev = d

        # PID
        u_p = self.Kp * e
        u_d = self.Kd * d

        # tentative integral
        I_new = self.I + self.Ki * e * dt
        u_unsat = u_p + I_new + u_d

        # clamp + simple anti-windup (conditional integration)
        if u_unsat > self.u_max:
            # if error drives further into saturation, don't accept new I
            if e > 0.0:
                u = self.u_max
            else:
                self.I = I_new
                u = min(u_unsat, self.u_max)
        elif u_unsat < -self.u_max:
            if e < 0.0:
                u = -self.u_max
            else:
                self.I = I_new
                u = max(u_unsat, -self.u_max)
        else:
            self.I = I_new
            u = u_unsat

        return float(u)


# ----------------- ROS2 Node -----------------
class YawPIDNode(Node):
    def __init__(
        self,
        ns: str,
        pose_topic: str,
        yaw_ref_topic: str,
        thruster_topic_fmt: str,
        left_ids: List[int],
        right_ids: List[int],
        rate_hz: float,
        kp: float, ki: float, kd: float, tau_d: float, u_max: float
    ):
        super().__init__("yaw_pid_node")

        self.ns = ns
        self.pose_topic = pose_topic
        self.yaw_ref_topic = yaw_ref_topic
        self.thruster_topic_fmt = thruster_topic_fmt
        self.left_ids = list(left_ids)
        self.right_ids = list(right_ids)
        self.dt = 1.0 / max(rate_hz, 1e-3)

        # State
        self.yaw_ref: float = 0.0
        self.yaw: float = 0.0
        self.yaw_rate: float = 0.0
        self.have_odom = False
        self.have_ref = False

        # Controller
        self.pid = YawPID(kp=kp, ki=ki, kd=kd, u_max=u_max, tau_d=tau_d)

        # Subs
        self.sub_odom = self.create_subscription(Odometry, self.pose_topic, self._pose_callback, 20)
        self.sub_ref  = self.create_subscription(Float32,  self.yaw_ref_topic, self.cb_ref, 10)
        self._wait_for_initial_state()
    
        # Pubs (make a publisher per thruster index we’ll use)
        self.pubs = {}
        used_ids = sorted(set(self.left_ids + self.right_ids))
        for i in used_ids:
            _id = f"id{i}"
            topic = self.thruster_topic_fmt.format(ns=self.ns, i=_id)
            self.pubs[i] = self.create_publisher(FloatStamped, topic, 10)
            self.get_logger().info(f"Publishing thruster commands to '{topic}'")
        

        # Control timer
        self.timer = self.create_timer(self.dt, self.control_step)
        self.get_logger().info(
            f"Yaw PID running at {1.0/self.dt:.1f} Hz | kp={kp}, ki={ki}, kd={kd}, tau_d={tau_d}, u_max={u_max}"
        )
        self.get_logger().info(f"Odometry: '{self.pose_topic}', Yaw ref: '{self.yaw_ref_topic}'")

    def _wait_for_initial_state(self) -> None:
        self.node.get_logger().info(f"Waiting for initial pose from {self.pose_topic}…")
        t0 = time.time()
        timeout = 20.0
        while self.current_position is None and rclpy.ok() and (time.time() - t0) < timeout:
            rclpy.spin_once(self.node, timeout_sec=0.1)
        if self.current_position is None:
            self.node.get_logger().error("Never received initial pose. Shutting down.")
            self.close()
            sys.exit("Initial state not received.")
        self.node.get_logger().info("Initial pose received.")

    # ----- Callbacks -----
    def _pose_callback(self, msg: Odometry) -> None:
        # if RclpyTime.from_msg(msg.header.stamp) > self.reset_start_time:
        #     self.pose_updated_after_reset = True

        q = msg.pose.pose.orientation
        self.yaw = quat_to_yaw(q.x, q.y, q.z, q.w)
        self.yaw_rate = float(msg.twist.twist.angular.z)
        self.have_odom = True
        self._last_pose_time = RclpyTime.from_msg(msg.header.stamp)

    # def cb_odom(self, msg: Odometry):
    #     q = msg.pose.pose.orientation
    #     self.yaw = quat_to_yaw(q.x, q.y, q.z, q.w)
    #     self.yaw_rate = float(msg.twist.twist.angular.z)
    #     self.have_odom = True

    def cb_ref(self, msg: Float32):
        # Expected in radians
        self.yaw_ref = float(msg.data)
        self.have_ref = True

    # ----- Control loop -----
    def control_step(self):
        if not self.have_odom:
            self.get_logger().info("Waiting for odometry…")
            return
        if not self.have_ref:
            self.get_logger().info("Waiting for yaw reference…")
            return

        u = self.pid.step(self.yaw_ref, self.yaw, self.dt, yaw_rate=self.yaw_rate)

        # Map to thrusters: left=+u, right=-u (flip sign if yaw direction is opposite)
        self.publish_group(self.left_ids,  +u)
        self.publish_group(self.right_ids, -u)

        # (Optional) debug
        # self.get_logger().info(f"yaw_ref={self.yaw_ref:.3f} yaw={self.yaw:.3f} e={ang_diff(self.yaw_ref,self.yaw):.3f} u={u:.1f}")

    def publish_group(self, ids: List[int], val: float):
        msg = FloatStamped()
        msg.header.stamp = self.get_clock().now().to_msg()
        msg.data = float(val)
        for i in ids:
            pub = self.pubs.get(i)
            if pub is not None:
                pub.publish(msg)


# ----------------- main -----------------
def main():
    parser = argparse.ArgumentParser(description="Pure ROS2 PID yaw controller for UUV")
    parser.add_argument("--ns", type=str, default="training_env1_x300",
                        help="Robot namespace used in topics, e.g. training_env1_x300")
    parser.add_argument("--pose-topic", type=str, default="{ns}/pose_gt",
                        help="Odometry topic (nav_msgs/Odometry). Use {ns} for namespace")
    parser.add_argument("--yaw-ref-topic", type=str, default="{ns}/yaw_ref",
                        help="Yaw reference topic (std_msgs/Float32, radians). Use {ns} for namespace")
    parser.add_argument("--thruster-topic-fmt", type=str, default="{ns}/thrusters/{i}/input",
                        help="Thruster command topic fmt (FloatStamped). Use {ns} and {i}")

    parser.add_argument("--left-ids", type=int, nargs="+", default=[3, 8],
                        help="Thruster IDs for left/port yaw group")
    parser.add_argument("--right-ids", type=int, nargs="+", default=[2, 7],
                        help="Thruster IDs for right/starboard yaw group")

    parser.add_argument("--rate", type=float, default=10.0, help="Control rate Hz")
    parser.add_argument("--kp", type=float, default=200.0)
    parser.add_argument("--ki", type=float, default=15.0)
    parser.add_argument("--kd", type=float, default=35.0)
    parser.add_argument("--tau-d", type=float, default=0.05, dest="tau_d", help="Derivative low-pass time constant (s)")
    parser.add_argument("--u-max", type=float, default=400.0, dest="u_max", help="Thruster magnitude limit")
    parser.add_argument("--world-launch", type=str, default="/home/alice/ros2_ws/install/uuv_gazebo_worlds/share/uuv_gazebo_worlds/launch/empty_underwater_world.launch.py",
                        help="ros2 launch target for the world (pkg/file or path)")
    parser.add_argument("--model-launch", type=str, default="/home/alice/ros2_ws/install/x300_description/share/x300_description/launch/upload_x300_default.launch.py",
                        help="ros2 launch target for the robot (pkg/file or path)")
    parser.add_argument("--headless", action="store_false", help="Run Gazebo without GUI")
    parser.add_argument("--ros-domain-id", type=int, default=51)
    parser.add_argument("--gazebo-port", type=int, default=11346)
    parser.add_argument("--entity-name", type=str, default=None)
    args = parser.parse_args()

    sim = None
    def normalize(s): 
        return s if " " in s else s  # keep simple; user supplies the right token

    sim = SimLauncher(
        world_launch=normalize(args.world_launch),
        model_launch=normalize(args.model_launch),
        ns=args.ns,
        entity_name=args.entity_name or f"{args.ns}_entity",
        headless=args.headless,
        ros_domain_id=args.ros_domain_id,
        gazebo_port=args.gazebo_port
    )
    sim.start()
    atexit.register(sim.stop)

    rclpy.init()
    node = YawPIDNode(
        ns=args.ns,
        pose_topic=args.pose_topic.format(ns=args.ns),
        yaw_ref_topic=args.yaw_ref_topic.format(ns=args.ns),
        thruster_topic_fmt=args.thruster_topic_fmt,
        left_ids=args.left_ids,
        right_ids=args.right_ids,
        rate_hz=args.rate,
        kp=args.kp, ki=args.ki, kd=args.kd, tau_d=args.tau_d, u_max=args.u_max
    )
    try:
        rclpy.spin(node)
    finally:
        node.destroy_node()
        rclpy.shutdown()


if __name__ == "__main__":
    main()
