import gymnasium as gym  # New standard after Gym v21.0
import envs

def test_env(env_name):
    # num_episodes=1
    # max_steps=100
    env = gym.make(env_name)
    print(f"Testing environment: {env_name}")
    
    for episode in range(3):
        print(f"\n--- Episode {episode + 1} ---")
        obs,info = env.reset()  # Reset the environment
        # print(f"Initial Observation: {obs}")
        
        total_reward = 0
        
        for step in range(5000):
            # Sample a random action from the action space
            # action = env.action_space.sample()
            # print(action)
            action = [1.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0] #only the back thruster turns on
            # Take the action in the environment
            next_obs, reward, terminated,truncated, info = env.step(action)
            # print(f"Step {step + 1}: Action: {action}, Next Observation: {next_obs}, Reward: {reward}, Done: {done}, Info: {info}")
                
            # Update the total reward
            total_reward += reward
            
            # If the episode ends, break the loop
            if terminated or truncated:
                print(f"Episode DONE after {step + 1} steps.")
                break
        
        print(f"Total Reward for Episode {episode + 1}: {total_reward}")
    
    # Close the environment
    env.close()

test_env("Nerites_mission_planning-v0")